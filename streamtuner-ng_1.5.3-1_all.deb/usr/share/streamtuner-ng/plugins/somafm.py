"""SomaFM — curated, commercial-free. st2 hardcoded the list; we use the live
`channels.json` feed (even st2 2.2.2 still hardcodes it, so this is an upgrade)."""

from __future__ import annotations

import time

from ...net import http
from ..base import Channel, make_row

FEED = "https://somafm.com/channels.json"
_QUALITY_RANK = {"highest": 3, "high": 2, "low": 1}
_FMT_MIME = {"mp3": "audio/mpeg", "aac": "audio/aac", "aacp": "audio/aac"}
_FMT_LABEL = {"mp3": "MP3", "aac": "AAC", "aacp": "AAC+"}


class SomaFM(Channel):
    id = "somafm"
    title = "SomaFM"
    description = "Listener-supported, commercial-free, underground/independent radio."
    homepage = "https://somafm.com/"
    priority = "standard"      # on by default
    row_fields = ('genre', 'format', 'listeners', 'description', 'playing', 'homepage')
    category_pins = ("All",)   # "All" on top; genres sort A–Z
    extra_columns = [("DJ", "dj"), ("Updated", "updated", "date"), ("Streams", "streams")]
    extra_columns_hidden = ("updated", "streams")
    all_category = "All"

    def __init__(self, config=None):
        super().__init__(config)
        self._channels: list[dict] = []

    def _fetch(self) -> list[dict]:
        generation, cached, current = self._snapshot_read("channels")
        if current:
            self._channels = cached
            return cached
        try:
            data = http.get_json(FEED)
            channels = data.get("channels", [])
        except Exception:
            has_newer, newer = self._snapshot_after_error("channels", generation)
            if has_newer:
                return newer
            raise
        channels = self._snapshot_publish("channels", generation, channels)
        self._channels = channels
        return channels

    @staticmethod
    def _best_playlist(ch: dict) -> tuple[str, str]:
        """Pick the highest-quality playlist; return (url, mime)."""
        pls = ch.get("playlists", [])
        # highest quality first; prefer mp3 for broad player support on ties
        pls = sorted(
            pls,
            key=lambda p: (_QUALITY_RANK.get(p.get("quality", ""), 0),
                           1 if p.get("format") == "mp3" else 0),
            reverse=True,
        )
        if not pls:
            return "", ""
        top = pls[0]
        return top.get("url", ""), _FMT_MIME.get(top.get("format", ""), "audio/mpeg")

    def invalidate_cache(self) -> None:
        super().invalidate_cache()

    def update_categories(self) -> list[str]:
        chans = self._fetch()
        genres = sorted({(c.get("genre") or "").split("|")[0] for c in chans if c.get("genre")})
        return ["All"] + genres

    def update_streams(self, category: str, search: str | None = None) -> list[dict]:
        _generation, _cached, current = self._snapshot_read("channels")
        chans = self._fetch() if not current else self._channels
        rows = []
        for c in chans:
            genre = c.get("genre", "")
            if category not in ("All", "", None) and not genre.startswith(category):
                continue
            if search and search.lower() not in (c.get("title", "") + c.get("description", "")).lower():
                continue
            url, mime = self._best_playlist(c)
            formats = list(dict.fromkeys(_FMT_LABEL.get(p.get("format"), "") for p in c.get("playlists", [])
                                         if isinstance(p, dict)))
            try:
                updated = time.strftime("%Y-%m-%d", time.gmtime(int(c.get("updated"))))
            except (TypeError, ValueError, OverflowError, OSError):
                updated = ""
            rows.append(make_row(
                title=c.get("title", ""),
                url=url,
                homepage="https://somafm.com/" + c.get("id", "") + "/",
                favicon=c.get("image", ""),
                genre=genre,
                description=c.get("description", ""),   # SomaFM tagline, not a song
                playing=c.get("lastPlaying", "") or "",
                listeners=c.get("listeners") or 0,  # normalized safely at the host boundary
                format=mime,
                listformat="pls",
                extra={"dj": c.get("dj"), "updated": updated, "streams": ", ".join(f for f in formats if f)},
            ))
        return rows

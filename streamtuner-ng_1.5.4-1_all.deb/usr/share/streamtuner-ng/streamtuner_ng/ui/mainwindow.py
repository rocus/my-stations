"""The main window — three panes (channels -> categories -> stations), toolbar,
persistent player bar, status bar, menus. Thin: it drives host/player/config and
keeps the airlock off the UI thread via worker.run_async.
"""

from __future__ import annotations

import time
import threading
from concurrent.futures import CancelledError
from collections import OrderedDict

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QAction, QFontMetrics, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QComboBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMainWindow, QMenu, QPushButton, QSlider, QSplitter,
    QToolBar, QVBoxLayout, QWidget,
)

from .. import APP_NAME, __version__
from ..player.mpv_player import clean_icy_title
from ..plugins.result import Result, Status
from ..security import MAX_IMPORT_BYTES, MAX_ROWS, csv_cell, copy_url, redact_url, station_row, valid_url
from ..songhistory import SongHistory
from . import theme
from .models import COLUMNS, DEFAULT_HIDDEN, DEFAULT_WIDTH, DEFAULT_WIDTHS, FILTER_ROLE, SORT_ROLE, StationModel
from .fieldfilter import StationProxy, clean_spec, field_kind
from .navhistory import NavHistory, SideButtons
from .stationtable import StationTable
from .spectrogram import Spectrogram
from .vumeter import VuMeter
from .worker import run_async, run_io, run_cache, run_playback, run_credentials
from .cache import CatalogCache


class StickyMenu(QMenu):
    """A menu of check boxes that stays open while you tick several of them (Esc or a click
    elsewhere closes it). Tear it off (the dashed bar at the top) to keep it as a small window."""

    def mouseReleaseEvent(self, ev):
        action = self.actionAt(ev.position().toPoint())
        if action is not None and action.isCheckable() and action.isEnabled():
            action.trigger()
            return
        super().mouseReleaseEvent(ev)


class MainWindow(QMainWindow):
    nowplaying = Signal(str)   # marshals mpv's metadata callback onto the UI thread

    # Favorites + Local are INTERNAL features, not directory plugins: always pinned
    # at the top of the sidebar, and kept out of the enable/disable toggle lists.
    INTERNAL_CHANNELS = ("bookmarks", "local")
    _BUSY_RETRIES = 6                    # a first page refused for lack of a free request slot is asked again this often
    _CATEGORIES_REUSE_S = 120            # a background refresh reuses a category list fetched this recently
    _REFRESH_MAX_ROWS = 3000             # the 20-minute refresh leaves bigger lists to the 6-hour rule
    _CACHE_STALE_S = 6 * 3600           # disk cache older than this -> freshen in the background
    _REFRESH_EVERY_MS = 20 * 60 * 1000  # periodic background refresh of the current category
    _STREAM_RETRY_DELAYS_MS = (2000, 4000, 8000, 15000, 30000)   # tries after a stream drops, about a minute in all

    def __init__(self, config, host, player):
        super().__init__()
        self.config, self.host, self.player = config, host, player
        self.current_channel = ""
        self.current_category = ""
        self._nav = NavHistory()      # lists opened, for Back / Forward (mouse side buttons, Alt+Left/Right)
        self._last_row = None         # the last station that started playing: Play with nothing selected resumes it
        self._sort_owner = None       # the service whose table sort is on screen (a click on a category keeps it)
        self._refresh_due = False     # the 20-minute refresh came due while nobody was looking: do it on return
        self._stream_retries = 0      # automatic tries after a dropped stream (reset once it plays steadily)
        self._retry_token = 0         # a pending retry belongs to the newest token only
        self._retry_pending = False
        self._retrying = False
        self._np_full = ""
        self._np_meta = ""            # bitrate/codec suffix shown right after the title
        self._play_gen = 0
        self._play_started_at = 0.0
        self._closing = False
        self._close_waiting = False
        self._close_timer = QTimer(self)
        self._close_timer.setSingleShot(True)
        self._close_timer.timeout.connect(self.close)
        self._secret_saves = set()
        self._secret_edit_pending = set()
        self._load_gen = 0           # bumps each category change; stale pages ignored
        self._channel_gen = 0
        self._cat_cancel = threading.Event()       # stops the category fetch of a service the view has left
        self._view_search = False
        self._search_query = None
        self._cache_epoch: dict[str, int] = {}
        self._loading_key = None
        self._page_retries = set()
        self._busy_retries = {}
        self._load_cancel = threading.Event()
        self._play_cancel = threading.Event()
        self._icon_cancel = threading.Event()
        self._local_add_pending = False
        self._local_add_state = None
        self._cache_events = {}
        self._cache_generation = 0
        self._icon_epoch = 0
        self._icon_retry_at = OrderedDict()
        self._cat_ages = {}
        self._load_complete = True
        self._load_errors = []
        self._load_notes = []
        self._load_started = False
        self._retain_during_load = False
        self._fresh_rows = []
        self._fresh_seen = set()
        self._refresh_view_key = None
        self._icons_clearing = False
        self._refreshing = False
        self._pending_restore = None
        self._search_failures = {}
        self.ALL_LIMIT = 100000
        self._collapsed = set(self.config.get("collapsed_groups", []) or [])
        self._cache = CatalogCache()   # (channel, category) -> full station list
        self._cat_cache: dict[str, list] = {}  # channel -> category list (cached on first visit)
        self._favicons: dict[str, str] = {}   # channel id -> cached favicon path
        self._svc_icons: dict = {}            # channel id -> QIcon, generic fallback for icon-less rows
        self._station_icons = OrderedDict()        # station favicon URL -> QIcon (None = in-flight)
        self._derived_icons = OrderedDict()        # station URL -> QIcon for favicon-less rows (SHOUTcast/TuneIn); None=in-flight, "miss"=none
        self._station_favicons = self.config.icon_mode() != "off"   # off -> service logo for all (full/small differ only on disk)
        self._pending_play = False
        self._playing_row: dict | None = None     # the row currently streaming (for the album-art box)
        self._show_art = bool(self.config.get("show_album_art", True))
        self._viz = self.config.get("visualization", "")
        if self._viz not in ("off", "vu", "spectrogram"):   # migrate the old show_vu bool
            self._viz = "vu" if self.config.get("show_vu", True) else "off"
        self._notifications = bool(self.config.get("notifications", True))  # OS now-playing toasts
        self._last_notified_title = ""        # de-dupe: only notify when the track title changes
        self._muted = False                       # mute is never remembered: the app always starts with sound
        self._normalize = bool(self.config.get("normalize", False))   # loudness normalization (dynaudnorm)
        self._discord = None                  # Discord Rich Presence (created lazily when enabled)
        self._discord_pending = None          # throttle: latest queued presence (tuple, or "CLEAR")
        self._discord_last = 0.0              # monotonic time the last presence was actually sent
        self._song_history = SongHistory(self.config)   # every song heard, saved with its time (View → Song history)
        self._song_window = None
        self._playing_row_url = ""            # url of the row currently streaming
        self._pending_filter = ""
        self._search_timer = QTimer(self)     # debounce search (smooth on huge lists)
        self._search_timer.setSingleShot(True)
        self._search_timer.timeout.connect(self._apply_filter)
        self._icon_dirty: set = set()         # favicon addresses / station URLs whose icon arrived since the last repaint
        self._icon_refresh = QTimer(self)     # coalesce lazy station-favicon repaints into one
        self._icon_refresh.setSingleShot(True)
        self._icon_refresh.timeout.connect(self._flush_icon_refresh)
        self.setWindowTitle(f"{APP_NAME} {__version__}")
        self.resize(1060, 660)

        self._build_toolbar()
        self._build_panes()
        self._build_playerbar()
        self._build_menus()
        self.statusBar().showMessage("Ready")

        # permanent status-bar items: streaming bitrate/buffer (left) + cache count (right)
        self._stream_label = QLabel()
        self._cache_label = QLabel()
        self.statusBar().addPermanentWidget(self._stream_label)
        self.statusBar().addPermanentWidget(self._cache_label)
        self._playing_bitrate = 0
        self._update_cache_label()
        self._stats_timer = QTimer(self)
        self._stats_timer.timeout.connect(self._update_stream_status)
        self._stats_timer.start(1000)
        self._vu_timer = QTimer(self)            # ~30 fps level-meter poll
        self._vu_timer.timeout.connect(self._tick_viz)
        # Visual polling starts only for visible, active playback.
        self._song_ask_gen = 0                   # F5 in Favorites: a newer ask replaces an older one
        self._field_filters: dict[str, dict[str, dict]] = {}   # feed id -> {field: filter spec}, for this session
        self._reload_all_job = None              # View -> Reload all, created on first use
        self._bg_done: dict = {}                 # (cid, cat) -> callback(ok) for Reload all
        self._bg_inflight: set = set()           # (cid, cat) currently being background-refreshed
        self._refresh_timer = QTimer(self)       # periodic freshening of the viewed category
        self._refresh_timer.timeout.connect(self._periodic_refresh)
        self._refresh_timer.start(self._REFRESH_EVERY_MS)
        self._discord_timer = QTimer(self)       # coalesce bursts of presence updates (rate limit)
        self._discord_timer.setSingleShot(True)
        self._discord_timer.timeout.connect(self._discord_flush)

        self.player.on_nowplaying = lambda t: self.nowplaying.emit(t)
        self.nowplaying.connect(self._on_nowplaying)

        self._populate_channels()
        self._load_channel_favicons()
        self._restore_layout()           # restore saved window size + column layout
        if not self.player.available:
            why = self.player.error or "libmpv not found"
            self.statusBar().showMessage(f"No audio engine — {why}")
            self._stream_label.setToolTip(why)        # hover the ⚠ for the full reason
        self.player.set_normalize(self._normalize)   # apply the saved loudness-normalization setting
        self._setup_shortcuts()
        self._side_buttons = SideButtons(self, self._nav_go)   # mouse Back / Forward buttons
        self._setup_media_keys()
        self._apply_appearance(self.config.get("theme", "dark"))   # apply wallpaper (if any) over the base theme

    # ---- construction ----
    def _build_toolbar(self) -> None:
        tb = QToolBar()
        tb.setMovable(False)
        self.addToolBar(tb)
        self.act_reload = QAction("Reload", self, triggered=self._reload)
        self.act_fav = QAction("Favorite", self, checkable=True, triggered=self._toggle_favourite)   # its star is the icon
        self.act_add_local = QAction("Add station…", self, triggered=self._add_local)
        self.act_add_local.setShortcut("Ctrl+N")
        self.act_add_local.setToolTip("Add one or more direct stream URLs to Local")
        self.act_add_local.setStatusTip("Save a stream URL in your Local station list")
        self.act_play = QAction("Play", self, triggered=self._play_selected)
        self.act_stop = QAction("Stop", self, triggered=self._stop)
        tb.addAction(self.act_reload)
        tb.addAction(self.act_add_local)
        tb.addAction(self.act_fav)
        fav_button = tb.widgetForAction(self.act_fav)
        if fav_button is not None:
            fav_button.setObjectName("favButton")                  # the theme does not light the whole button when checked
            fav_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._paint_favourite_star(self.config.get("theme", "dark"))
        tb.addSeparator()                       # | between Favorite and the transport
        tb.addWidget(QLabel(" Search: "))
        self.search = QLineEdit()
        self.search.setPlaceholderText("filter…  (Enter = search the directory)")
        self.search.setClearButtonEnabled(True)   # ✕ button to clear the filter
        self.search.setMinimumWidth(180)
        self.search.textChanged.connect(self._on_search)        # type = instant client-side filter
        self.search.returnPressed.connect(self._search_enter)   # Enter = server-side directory search
        tb.addWidget(self.search)
        self.search_scope = QComboBox()
        self.search_scope.addItems(["Loaded list", "This source", "All sources"])
        self.search_scope.currentIndexChanged.connect(self._scope_changed)
        self.search_scope.setToolTip(
            "Where to search:\n"
            "Loaded list — filter the stations shown\n"
            "This source — the feed's own search\n"
            "All sources — every feed that can search (Ctrl+Shift+F)")
        for index, tip in enumerate(("Filter the stations shown", "Search this feed with its own search",
                                     "Search every feed that can search")):
            self.search_scope.setItemData(index, tip, Qt.ToolTipRole)
        tb.addWidget(self.search_scope)
        self.search_submit = QPushButton("Search")
        self.search_submit.clicked.connect(self._search_enter)
        self._search_submit_action = tb.addWidget(self.search_submit)
        self._scope_changed()

    def _build_panes(self) -> None:
        self._pane_headers = {}                           # pane widget -> its heading label (focus marker)
        self.channels = QListWidget()
        self.channels.currentItemChanged.connect(self._on_channel)
        self.channels.setContextMenuPolicy(Qt.CustomContextMenu)
        self.channels.customContextMenuRequested.connect(self._channel_menu)

        self.categories = QListWidget()
        self.categories.currentItemChanged.connect(self._on_category)
        for pane in (self.channels, self.categories):     # long names scroll sideways instead of clipping
            pane.setTextElideMode(Qt.ElideNone)
            pane.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
            pane.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            pane.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.categories.itemDoubleClicked.connect(self._reload_category)

        self.model = StationModel()
        bm = self.host.channels.get("bookmarks")
        self.model.fav_provider = bm.is_favourite if bm else None
        self.model.icon_provider = self._station_icon
        self.model.source_provider = self._source_label
        self.proxy = StationProxy()
        self.proxy.setSourceModel(self.model)
        self.proxy.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self.proxy.setFilterKeyColumn(0)
        self.proxy.setFilterRole(FILTER_ROLE)    # search matches name + genre + country
        self.proxy.setSortRole(SORT_ROLE)        # numeric columns sort numerically
        self.table = StationTable()
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setSortingEnabled(True)
        self.table.verticalHeader().setVisible(False)
        hdr = self.table.horizontalHeader()
        hdr.setSectionsMovable(True)                        # drag headers to reorder
        hdr.setSectionResizeMode(QHeaderView.Interactive)   # drag edges to resize
        hdr.setStretchLastSection(True)                     # last column fills the gap
        for col, (_label, field) in enumerate(self.model.columns()):
            self.table.setColumnWidth(col, DEFAULT_WIDTHS.get(field, DEFAULT_WIDTH))
        self._columns_panel = None                           # the movable "Fields" window, created on first use
        self._layout_applied = None                          # column set the saved widths/order were applied to
        self._layout_applying = False
        self._layout_timer = QTimer(self)
        self._layout_timer.setSingleShot(True)
        self._layout_timer.setInterval(300)
        self._layout_timer.timeout.connect(self._save_column_layout)
        hdr.sectionResized.connect(self._column_layout_changed)
        hdr.sectionMoved.connect(self._column_layout_changed)
        hdr.sectionMoved.connect(lambda *_: self._refresh_columns_panel())
        hdr.setContextMenuPolicy(Qt.CustomContextMenu)       # right-click a header: choose the fields
        hdr.customContextMenuRequested.connect(self._header_menu)
        self.table.doubleClicked.connect(self._play_selected)
        self.table.clicked.connect(self._on_station_clicked)
        self.table.selectionModel().currentRowChanged.connect(lambda *_: self._sync_selection_actions())
        self.table.verticalScrollBar().sliderPressed.connect(lambda: setattr(self, "_pending_restore", None))
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._station_menu)

        split = QSplitter(Qt.Horizontal)
        self._services_pane = self._titled_pane("Services", self.channels)
        split.addWidget(self._services_pane)
        # album-art / station-logo box: floats at the bottom-left of the Services pane (overlay,
        # never reflows the list or the splitter); sized to its image.
        self.art = QLabel(self._services_pane)
        self.art.setObjectName("artBox")
        self.art.setAlignment(Qt.AlignCenter)
        self.art.hide()
        self._services_pane.installEventFilter(self)
        split.addWidget(self._titled_pane("Categories", self.categories))
        station_pane = QWidget()
        station_layout = QVBoxLayout(station_pane)
        station_layout.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        self._list_notice = QLabel("Choose a service to browse stations")
        self._list_notice.setTextFormat(Qt.PlainText)
        self._list_notice.setWordWrap(True)
        row.addWidget(self._list_notice, 1)
        self._back_button = QPushButton("Back to category")
        self._back_button.clicked.connect(self._back_to_category)
        self._back_button.hide()
        row.addWidget(self._back_button)
        self._retry_button = QPushButton("Retry")
        self._retry_button.clicked.connect(self._retry_failed_search)
        self._retry_button.hide()
        row.addWidget(self._retry_button)
        self._cancel_button = QPushButton("Cancel loading")
        self._cancel_button.clicked.connect(self._cancel_load)
        self._cancel_button.hide()
        row.addWidget(self._cancel_button)
        station_layout.addLayout(row)
        station_layout.addWidget(self.table)
        split.addWidget(station_pane)
        self._split = split
        self._pane_headers.setdefault(self.table, None)   # the table marks focus with its own outline
        for pane in self._pane_headers:
            pane.installEventFilter(self)
        self.setTabOrder(self.channels, self.categories)
        self.setTabOrder(self.categories, self.table)
        split.setStretchFactor(2, 1)
        split.setSizes([160, 170, 730])

        from .wallpaper import WallpaperWidget
        central = WallpaperWidget()           # paints the optional wallpaper behind everything
        self._wallpaper_widget = central
        lay = QVBoxLayout(central)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.addWidget(split, 1)
        self._central_layout = lay
        self.setCentralWidget(central)

    def _titled_pane(self, title: str, widget) -> QWidget:
        """Wrap a pane with a header label (so the Services/Categories columns are
        labelled, matching the station table's column headers)."""
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        header = QLabel(title)
        header.setObjectName("paneHeader")
        v.addWidget(header)
        v.addWidget(widget)
        self._pane_headers[widget] = header
        return box

    # ---- keyboard between the three panes (Services -> Categories -> Stations) ----
    def _pane_cycle(self) -> list:
        return [self.channels, self.categories, self.table]

    def _focus_pane(self, pane) -> None:
        pane.setFocus(Qt.TabFocusReason)
        if pane is self.categories and self.categories.currentRow() < 0 and self.categories.count():
            self.categories.setCurrentRow(0)                 # entering an empty selection lands on the first entry
        elif pane is self.channels and self.channels.currentRow() < 0 and self.channels.count():
            self.channels.setCurrentRow(0)
        elif pane is self.table and not self.table.currentIndex().isValid() and self.proxy.rowCount():
            self.table.setCurrentIndex(self.proxy.index(0, 0))

    def _step_pane(self, delta: int) -> None:
        panes = self._pane_cycle()
        focus = QApplication.focusWidget()
        here = next((i for i, p in enumerate(panes) if p is focus or p.isAncestorOf(focus)), -1) if focus else -1
        self._focus_pane(panes[(here + delta) % len(panes)] if here >= 0 else panes[0])

    def _mark_focus(self, pane, on: bool) -> None:
        header = self._pane_headers.get(pane)
        if header is not None:
            header.setProperty("focused", "true" if on else "false")
            header.style().unpolish(header)
            header.style().polish(header)

    def _pane_key(self, obj, ev) -> bool:
        """Tab/Shift+Tab/F6 move between panes; Right or Enter goes on in the two lists, Left goes back."""
        key = ev.key()
        if key in (Qt.Key_Tab, Qt.Key_Backtab) and not (ev.modifiers() & (Qt.ControlModifier | Qt.AltModifier)):
            self._step_pane(-1 if key == Qt.Key_Backtab or ev.modifiers() & Qt.ShiftModifier else 1)
            return True
        if obj is self.table and key in (Qt.Key_Return, Qt.Key_Enter) and not ev.modifiers():
            self._play_selected()                            # Enter in the station list plays, like a double-click
            return True
        if obj is self.table and key == Qt.Key_Delete and not ev.modifiers():
            return self._delete_selected()
        if obj is self.channels or obj is self.categories:
            nxt = self.categories if obj is self.channels else self.table
            if key in (Qt.Key_Right, Qt.Key_Return, Qt.Key_Enter) and not ev.modifiers():
                self._focus_pane(nxt)
                return True
            if key == Qt.Key_Left and obj is self.categories and not ev.modifiers():
                self._focus_pane(self.channels)
                return True
        return False

    # ---- album-art box (floats bottom-left of the Services pane) ----
    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if obj is getattr(self, "_services_pane", None) and ev.type() == QEvent.Resize:
            self._position_art()
        elif obj in getattr(self, "_pane_headers", ()):
            kind = ev.type()
            if kind == QEvent.KeyPress and self._pane_key(obj, ev):
                return True
            if kind == QEvent.FocusIn:
                self._mark_focus(obj, True)
            elif kind == QEvent.FocusOut:
                self._mark_focus(obj, False)
        return super().eventFilter(obj, ev)

    # ---- back / forward through the lists opened ----
    def _nav_update(self) -> None:
        back, forward = getattr(self, "_back_action", None), getattr(self, "_forward_action", None)
        if back is not None and forward is not None:
            back.setEnabled(self._view_search or self._nav.can_back())
            forward.setEnabled(self._nav.can_forward())

    def _nav_exists(self, key) -> bool:
        return any(self.channels.item(i).data(Qt.UserRole) == key[0] for i in range(self.channels.count()))

    def _nav_go(self, delta: int) -> None:
        """Back (-1) or Forward (+1) to the list opened before or after this one. Back first leaves a
        search-results view, which is itself a step away from the list."""
        if delta < 0 and self._view_search:
            self._back_to_category()
            return
        key = self._nav.step(delta, self._nav_exists)
        if key is None:
            self.statusBar().showMessage("No earlier list" if delta < 0 else "No later list", 1500)
            return
        cid, cat = key
        if cid == self.current_channel:
            items = self.categories.findItems(cat, Qt.MatchExactly)
            if not items:
                self._nav.forget(key)
                self.statusBar().showMessage(f"{cat} is no longer in this service", 2500)
            else:
                self.categories.setCurrentItem(items[0])
        else:
            item = next(self.channels.item(i) for i in range(self.channels.count())
                        if self.channels.item(i).data(Qt.UserRole) == cid)
            self.channels.setCurrentItem(item)
        self._nav_update()

    def _position_art(self) -> None:
        pm = self.art.pixmap()
        if self.art.isHidden() or pm.isNull():
            return
        m = 6
        y = self._services_pane.height() - pm.height() - m
        self.art.setGeometry(m, max(0, y), pm.width(), pm.height())
        self.art.raise_()

    def _update_art(self) -> None:
        """Now-playing artwork in the bottom-left box. Shows the source service's logo immediately,
        then upgrades async to the station's OWN image: the directory's per-station favicon if the
        row carries one, else the broadcaster's real logo derived from the stream's ICY `icy-url` —
        so a Shoutcast station shows its own site's favicon, not the generic Shoutcast logo.
        v2 will prefer the song's real cover art (Radio Paradise / Local mp3)."""
        if not self._show_art or self._playing_row is None:
            self.art.hide()
            return
        row = self._playing_row
        token = row.get("url", "")                     # token: ignore stale async results
        self._art_token = token
        pm = self._service_pixmap(row)                 # immediate fallback (service logo; may be None)
        if pm is not None and not pm.isNull():
            self._show_art_pixmap(pm)
        else:
            self.art.hide()                            # nothing local yet — wait for the fetch
        from ..favicons import best_station_icon          # cached-derived > directory favicon > derive
        run_io(lambda r=dict(row): best_station_icon(self.config, r),
               lambda path, t=token: self._apply_art(t, path))

    def _apply_art(self, token, path) -> None:
        if self._closing:
            return
        if not self._show_art or self._playing_row is None:
            return
        if token != getattr(self, "_art_token", ""):
            return                                     # a different stream started — stale result
        from PySide6.QtGui import QPixmap
        pm = QPixmap(path) if path else QPixmap()
        if not pm.isNull():
            self._show_art_pixmap(pm)
        elif self.art.pixmap().isNull():
            self.art.hide()

    def _show_art_pixmap(self, pm) -> None:
        floor, cap = 56, 140                           # tiny favicons get a visible floor; big art caps
        w = pm.width()
        if w > cap:
            pm = pm.scaledToWidth(cap, Qt.SmoothTransformation)
        elif 0 < w < floor:
            pm = pm.scaledToWidth(floor, Qt.SmoothTransformation)
        self.art.setPixmap(pm)
        self.art.resize(pm.size())
        self.art.show()
        self._position_art()                           # geometry + raise above the list, after show()

    def _service_pixmap(self, row):
        """Fallback art = the source service's logo (native size)."""
        from PySide6.QtGui import QPixmap
        cid = (row or {}).get("_source") or self.current_channel
        path = self._favicons.get(cid)
        if path:
            pm = QPixmap(path)
            if not pm.isNull():
                return pm
        return None

    def _toggle_art(self, on: bool) -> None:
        self._show_art = on
        self.config.set("show_album_art", on)
        self.config.save_settings()
        self._update_art()

    def _set_visualization(self, mode: str) -> None:
        self._viz = mode
        self.config.set("visualization", mode)
        self.config.save_settings()
        self.vu.setVisible(mode == "vu")
        self.spectro.setVisible(mode == "spectrogram")
        if mode == "spectrogram":
            self.spectro.reset_width()
        for m, a in self._viz_actions.items():
            a.setChecked(m == mode)
        self._sync_visualizer()

    def _build_playerbar(self) -> None:
        bar = QWidget()
        bar.setObjectName("playerBar")
        h = QHBoxLayout(bar)
        h.setContentsMargins(8, 4, 8, 4)
        self.btn_play = QPushButton("▶")
        self.btn_play.setCheckable(True)
        self.btn_play.setFixedWidth(40)
        self.btn_play.setToolTip("Play / Stop")
        self.btn_play.clicked.connect(self._toggle_play)
        self.btn_play.toggled.connect(lambda on: self.btn_play.setText("■" if on else "▶"))
        # (no station icon here — the now-playing artwork lives in the bottom-left art box)
        self.np_label = QLabel("Stopped")
        self.np_label.setTextFormat(Qt.PlainText)
        self.np_label.setMinimumWidth(200)
        self.np_label.setContextMenuPolicy(Qt.CustomContextMenu)        # right-click the track for options
        self.np_label.customContextMenuRequested.connect(self._nowplaying_menu)
        self.np_label.setToolTip("Right-click for track options (copy, info, website)")
        self.player.set_volume(self.config.get("volume", self.player.volume))   # restore saved volume
        self.vol = QSlider(Qt.Horizontal)
        self.vol.setFixedWidth(120)
        self.vol.setRange(0, 100)
        self.vol.setValue(self.player.volume)
        self.vol.valueChanged.connect(self.player.set_volume)
        self.vol.valueChanged.connect(lambda v: self.config.set("volume", v))   # saved on close
        self.vol.valueChanged.connect(lambda _v: self._set_muted(False))        # moving the slider un-mutes
        self.vol.sliderPressed.connect(lambda: self._set_muted(False))
        self.btn_vol = QPushButton("Vol")            # a click mutes / un-mutes (always starts un-muted)
        self.btn_vol.setObjectName("volButton")
        self.btn_vol.setFlat(True)
        self.btn_vol.setCursor(Qt.PointingHandCursor)
        self.btn_vol.setFocusPolicy(Qt.NoFocus)
        self.btn_vol.setStyleSheet(
            "QPushButton#volButton { border: none; background: transparent; padding: 4px 6px; }"
            "QPushButton#volButton:hover { background: transparent; text-decoration: underline; }"
            "QPushButton#volButton[muted=\"true\"] { color: rgb(239,119,113); font-weight: bold; }")
        self.btn_vol.setToolTip("Click to mute  (Ctrl+M)")
        self.btn_vol.clicked.connect(lambda *_: self._toggle_mute())
        self.vu = VuMeter()                          # live stereo level meter
        self.vu.setVisible(self._viz == "vu")
        self.spectro = Spectrogram()                 # alternative viz — same slot, resizable
        self.spectro.setVisible(self._viz == "spectrogram")
        self.btn_norm = QPushButton("Norm")          # lit green when on (theme QPushButton:checked)
        self.btn_norm.setCheckable(True)
        self.btn_norm.setChecked(self._normalize)
        self.btn_norm.setToolTip("Normalize loudness — even out the volume between stations")
        self.btn_norm.toggled.connect(self._toggle_normalize)
        h.addWidget(self.btn_play)
        h.addSpacing(10)                        # breathing room between ▶ and the now-playing text
        h.addWidget(self.np_label, 1)
        h.addWidget(self.vu)
        h.addWidget(self.spectro)
        h.addWidget(self._vsep())               # | between the visualization and the volume
        h.addWidget(self.btn_vol)
        h.addWidget(self.vol)
        h.addWidget(self.btn_norm)
        self._central_layout.insertWidget(0, bar)   # top, right under the toolbar

    def _vsep(self) -> QWidget:
        """A thin vertical divider for the player bar (the QHBoxLayout can't use
        QToolBar.addSeparator, so this matches it with a 1px grey line)."""
        from PySide6.QtWidgets import QFrame, QSizePolicy
        holder = QWidget()
        lay = QHBoxLayout(holder)
        lay.setContentsMargins(6, 3, 6, 3)
        line = QFrame()
        line.setFixedWidth(1)
        line.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        line.setStyleSheet("background: rgb(120,120,120);")
        lay.addWidget(line)
        return holder

    def _build_menus(self) -> None:
        import sys
        mb = self.menuBar()
        if sys.platform.startswith("linux"):
            # draw the menu bar in-window — skip any native/global-menu (DBus) detour.
            # macOS keeps its proper top-of-screen native bar; Windows is in-window anyway.
            mb.setNativeMenuBar(False)
        m_file = mb.addMenu("&File")
        m_file.addAction(QAction("Open Location…", self, shortcut="Ctrl+L", triggered=self._open_location))
        m_file.addAction(self.act_add_local)
        m_file.addSeparator()
        m_file.addAction(QAction("Quit", self, shortcut="Ctrl+Q", triggered=self._quit))

        m_view = mb.addMenu("&View")
        self._back_action = QAction("Back", self, shortcut="Alt+Left", triggered=lambda: self._nav_go(-1))
        self._forward_action = QAction("Forward", self, shortcut="Alt+Right", triggered=lambda: self._nav_go(1))
        for a, tip in ((self._back_action, "The list you looked at before (mouse Back button)"),
                       (self._forward_action, "Go on to the list you came back from (mouse Forward button)")):
            a.setToolTip(tip)
            a.setEnabled(False)
            m_view.addAction(a)
        m_view.addSeparator()
        m_view.addAction(QAction("Reload current channel", self, shortcut="F5", triggered=self._reload))
        self._reload_all_action = QAction("Reload all", self, shortcut="Shift+F5", triggered=self._reload_all)
        self._reload_all_action.setToolTip("Fetch every saved list of every service again, in the background")
        m_view.addAction(self._reload_all_action)
        self._columns_menu = StickyMenu("Columns", m_view)
        m_view.addMenu(self._columns_menu)
        self._column_actions = {}
        self._columns_sig = None
        self._columns_menu.aboutToShow.connect(self._rebuild_columns_menu)    # a service can add its own
        self._rebuild_columns_menu()
        self._art_action = QAction("Show album art", self, checkable=True)
        self._art_action.setChecked(self._show_art)
        self._art_action.triggered.connect(self._toggle_art)
        m_view.addAction(self._art_action)
        viz_menu = m_view.addMenu("Visualization")
        self._viz_actions = {}
        for mode, label in (("off", "Off"), ("vu", "VU Meter"), ("spectrogram", "Level history")):
            a = QAction(label, self, checkable=True)
            a.setChecked(self._viz == mode)
            a.triggered.connect(lambda _=False, m=mode: self._set_visualization(m))
            viz_menu.addAction(a)
            self._viz_actions[mode] = a
        m_view.addAction(QAction("Song history…", self, triggered=self._song_history_dialog))
        m_view.addSeparator()
        self._colors_menu = m_view.addMenu("Colors")
        self._build_colors_menu()
        self._theme_menu = m_view.addMenu("Theme")
        self._rebuild_theme_menu()
        self._wallpaper_menu = m_view.addMenu("Wallpaper")
        self._rebuild_wallpaper_menu()

        self.m_channels = mb.addMenu("&Services")
        self._rebuild_channels_menu()

        m_play = mb.addMenu("&Playback")
        m_play.addAction(self.act_play)
        m_play.addAction(self.act_stop)
        m_play.addSeparator()
        self.act_mute = QAction("Mute", self, checkable=True)
        self.act_mute.setShortcut("Ctrl+M")
        self.act_mute.triggered.connect(lambda on=False: self._set_muted(bool(on)))
        m_play.addAction(self.act_mute)
        self.act_normalize = QAction("Normalize loudness", self, checkable=True)
        self.act_normalize.setChecked(self._normalize)
        self.act_normalize.toggled.connect(self._toggle_normalize)
        m_play.addAction(self.act_normalize)

        m_tools = mb.addMenu("&Tools")
        m_tools.addAction(QAction("Options…", self, shortcut="Ctrl+,", triggered=self._open_options))
        m_tools.addAction(QAction("Open Plugins Folder…", self, triggered=self._open_plugins_folder))

        m_help = mb.addMenu("&Help")
        m_help.addAction(QAction("About", self, triggered=self._about))

    # ---- channel sidebar ----
    def _populate_channels(self) -> None:
        previous = self.current_channel
        self.channels.blockSignals(True)
        self.channels.clear()
        chans = list(self.host.shown_channels())
        # Favorites + Local are internal — always pinned at the top from the full
        # registry, regardless of their enabled/visible state (so they can never
        # vanish from a stale config). Then a divider, then the streaming services A–Z.
        top = [self.host.channels[cid] for cid in self.INTERNAL_CHANNELS
               if cid in self.host.channels]
        rest = sorted((c for c in chans if c.id not in self.INTERNAL_CHANNELS),
                      key=lambda c: c.title.lower())

        def add(ch) -> None:
            it = QListWidgetItem(ch.title)
            it.setData(Qt.UserRole, ch.id)
            it.setIcon(self._channel_icon(ch.id))
            self.channels.addItem(it)

        for ch in top:
            add(ch)
        if top and rest:
            self._add_channel_separator()
        for ch in rest:
            add(ch)
        chosen = next((i for i in range(self.channels.count())
                       if self.channels.item(i).data(Qt.UserRole) == previous), None)
        same = chosen is not None
        if chosen is None:
            chosen = next((i for i in range(self.channels.count())
                           if self.channels.item(i).data(Qt.UserRole)), None)
        if chosen is not None:
            self.channels.setCurrentRow(chosen)
        self.channels.blockSignals(False)
        if chosen is not None and not same:
            self._on_channel(self.channels.currentItem(), None)
        if self._field_filters:
            self._apply_field_filters()               # a rebuilt list keeps its "filtered" marks

    def _add_channel_separator(self) -> None:
        """A thin divider line in the Services list (separates Favorites/Local from the services)."""
        from PySide6.QtCore import QSize
        from PySide6.QtWidgets import QFrame
        sep = QListWidgetItem()
        sep.setFlags(Qt.NoItemFlags)              # non-selectable; no UserRole -> skipped on click
        sep.setSizeHint(QSize(0, 9))
        self.channels.addItem(sep)
        holder = QWidget()
        lay = QHBoxLayout(holder)
        lay.setContentsMargins(8, 4, 8, 4)
        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet("background: rgb(120,120,120);")
        lay.addWidget(line)
        self.channels.setItemWidget(sep, holder)

    def _rebuild_channels_menu(self) -> None:
        self.m_channels.clear()
        chans = self.host.channels
        internal = [chans[c] for c in self.INTERNAL_CHANNELS if c in chans]   # Favorites, Local first
        services = sorted((ch for cid, ch in chans.items()
                           if cid not in self.INTERNAL_CHANNELS and not ch.test_only),
                          key=lambda c: c.title.lower())                       # then services A–Z

        def add(ch, locked: bool) -> None:
            a = QAction(ch.title, self, checkable=True)
            if locked:                                   # internal feature: always on, can't toggle
                a.setChecked(True)
                a.setEnabled(False)
            else:
                enabled = self.host.is_enabled(ch.id)
                a.setChecked(self.host.is_visible(ch.id) and enabled)
                a.setEnabled(enabled)
                if not enabled:
                    a.setText(ch.title + " (disabled)")
                    a.setToolTip("Enable this service in Options → Plugins")
                a.toggled.connect(lambda on, c=ch.id: self._set_visible(c, on))
            self.m_channels.addAction(a)

        for ch in internal:
            add(ch, True)
        if internal and services:
            self.m_channels.addSeparator()              # divider, mirroring the sidebar
        for ch in services:
            add(ch, False)
        self.m_channels.addSeparator()
        self.m_channels.addAction(QAction("Manage Plugins…", self, triggered=self._open_options))

    def _set_visible(self, cid: str, on: bool) -> None:
        self.host.set_visible(cid, on)
        self._populate_channels()

    def _refresh_dot(self, cid: str) -> None:
        self._set_channel_icon(cid)

    # ---- channel icons (service favicon + health badge) ----
    def _channel_icon(self, cid: str):
        ch = self.host.channels.get(cid)
        return theme.channel_icon(self._favicons.get(cid), emoji=getattr(ch, "icon_emoji", ""))

    def _set_channel_icon(self, cid: str) -> None:
        for i in range(self.channels.count()):
            it = self.channels.item(i)
            if it.data(Qt.UserRole) == cid:
                it.setIcon(self._channel_icon(cid))
                break

    def _on_favicon(self, cid: str, path) -> None:
        if self._closing:
            return
        if isinstance(path, str) and path:
            self._favicons[cid] = path
            self._svc_icons.pop(cid, None)    # rebuild the generic fallback now that the logo is in
            self._set_channel_icon(cid)
            self.model.refresh_icons()        # paint generic icons for any icon-less rows on screen

    def _load_channel_favicons(self) -> None:
        from ..favicons import ensure_favicon
        for ch in self.host.channels.values():
            if ch.test_only or not self.host.is_enabled(ch.id) or not getattr(ch, "homepage", "") or ch.id in self._favicons:
                continue
            cid = ch.id
            run_io(lambda c=ch: ensure_favicon(self.config, c),
                   lambda path, cid=cid: self._on_favicon(cid, path))

    def _channel_menu(self, pos) -> None:
        item = self.channels.itemAt(pos)
        if not item or not item.data(Qt.UserRole):
            return
        cid = item.data(Qt.UserRole)
        ch = self.host.channels.get(cid)
        from PySide6.QtWidgets import QMenu
        menu = QMenu(self)
        home = getattr(ch, "homepage", "")
        if home and home.startswith("file:"):
            if getattr(ch, "local_files", False):
                menu.addAction("Open Folder", lambda: self._open_local_folder(home))
        elif home:
            menu.addAction("Open Website", lambda: self._open_website(home))
        if cid == "bookmarks":                   # Favorites: export favourites OR history; import (merge)
            menu.addAction("Export Favorites… (CSV)",
                           lambda: self._export_rows(getattr(ch, "favourite", []), "favorites.csv"))
            menu.addAction("Export History… (CSV)",
                           lambda: self._export_rows(getattr(ch, "history", []), "history.csv"))
            menu.addAction("Import to Favorites… (CSV)", self._import_favourites)
        elif cid == "local":                     # Local: export your own added streams
            menu.addAction("Export list… (CSV)",
                           lambda: self._export_rows(getattr(ch, "_rows", []), "local-stations.csv"))
        # plugin-declared right-click options (bitrate, login, …) from the channel's options_spec
        spec = getattr(ch, "options_spec", None) or []
        if spec and self.config is not None:
            menu.addSeparator()
            for opt in spec:
                self._add_channel_option(menu, opt)
        menu.addAction("Options…", self._open_options)
        menu.addAction("Refresh Icon", lambda: self._refresh_favicon(cid))
        try:
            menu.exec(self.channels.mapToGlobal(pos))
        finally:
            menu.deleteLater()

    def _add_channel_option(self, menu, opt) -> None:
        """Render one entry from a channel's options_spec into the right-click menu.
        'choice' -> an exclusive (lit-check) submenu; 'secret' -> a masked Set/Change dialog."""
        from PySide6.QtGui import QAction, QActionGroup
        typ, key, label = opt.get("type"), opt.get("key", ""), opt.get("label", "")
        if typ == "choice":
            sub = menu.addMenu(label or "Quality")
            grp = QActionGroup(sub)
            grp.setExclusive(True)
            cur = self.config.get(key, opt.get("default", ""))
            for clabel, cval in opt.get("choices", []):
                a = QAction(clabel, sub)
                a.setCheckable(True)
                a.setChecked(cval == cur)
                a.triggered.connect(lambda _=False, k=key, v=cval, lb=clabel: self._set_channel_option(k, v, lb))
                grp.addAction(a)
                sub.addAction(a)
        elif typ == "secret":
            menu.addAction(f"Set / change {label}…",
                           lambda k=key, lb=label, ph=opt.get("placeholder", ""): self._edit_channel_secret(k, lb, ph))

    def _set_channel_option(self, key: str, value, label: str = "") -> None:
        self.config.set(key, value)
        self.config.save_settings()
        self.statusBar().showMessage(f"Selected: {label}" if label else "Saved", 3000)

    def _edit_channel_secret(self, key: str, label: str, placeholder: str = "") -> None:
        from PySide6.QtWidgets import QInputDialog, QLineEdit
        if key in self._secret_edit_pending or self._closing:
            return
        self._secret_edit_pending.add(key)
        self.statusBar().showMessage(f"Loading {label}…")

        def loaded(current):
            if self._closing:
                self._secret_edit_pending.discard(key)
                return
            if isinstance(current, BaseException):
                self._secret_edit_pending.discard(key)
                self._status_error(f"Could not load {label}")
                return
            text, ok = QInputDialog.getText(self, label, f"{label}:", QLineEdit.Password,
                                            current or "")
            if not ok:
                self._secret_edit_pending.discard(key)
                return
            completed = threading.Event()
            self._secret_saves.add(completed)
            self.statusBar().showMessage(f"Saving {label}…")

            def save():
                try:
                    self.config.set(key, text.strip())
                    self.config.save_settings()
                finally:
                    completed.set()

            def saved(result):
                completed.set()  # queue rejection also completes the operation
                self._secret_saves.discard(completed)
                self._secret_edit_pending.discard(key)
                if self._closing:
                    return
                if isinstance(result, BaseException):
                    self._status_error(f"Could not save {label}; please retry")
                else:
                    self.statusBar().showMessage(f"{label} saved", 3000)

            run_credentials(save, saved)

        run_credentials(lambda: self.config.get(key, ""), loaded)

    def _export_rows(self, rows, suggested: str) -> None:
        """Save a stable station-list snapshot to CSV without blocking the UI."""
        import csv
        import os
        import tempfile
        from concurrent.futures import CancelledError
        from pathlib import Path
        from PySide6.QtWidgets import QFileDialog

        snapshot = tuple(rows or ())
        if not snapshot:
            self.statusBar().showMessage("Nothing to export — the list is empty.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export list", suggested, "CSV files (*.csv)")
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"
        destination = Path(path)
        cols = [("title", "Title"), ("url", "URL"), ("genre", "Genre"), ("country", "Country"),
                ("bitrate", "Bitrate"), ("format", "Format"), ("homepage", "Homepage")]
        labels = {field[2:]: label for label, field in self.model.columns() if field.startswith("x:")}
        extra_keys = []
        for item in snapshot:
            for key in (item.get("extra") or {}):
                if key not in extra_keys and len(extra_keys) < 12:
                    extra_keys.append(key)
        cols += [("x:" + key, labels.get(key, key.replace("_", " ").title())) for key in extra_keys]
        # Favorites/Local replace rows on mutation; they do not edit them in place.
        # Capturing the tuple keeps the exact list version selected by the user.
        secret_snapshot = tuple(self.config.secrets._cache.copy().values())
        cancel = threading.Event()
        if not hasattr(self, "_export_cancels"):
            self._export_cancels = set()
        self._export_cancels.add(cancel)
        self.statusBar().showMessage(f"Exporting {len(snapshot):,} stations…")

        def write_csv():
            fd = temporary = None
            try:
                fd, temporary = tempfile.mkstemp(prefix=destination.name + ".", suffix=".tmp",
                                                 dir=str(destination.parent))
                with os.fdopen(fd, "w", newline="", encoding="utf-8") as stream:
                    fd = None
                    writer = csv.writer(stream)
                    writer.writerow([heading for _key, heading in cols])
                    for row in snapshot:
                        if cancel.is_set():
                            raise CancelledError("CSV export cancelled")
                        writer.writerow([csv_cell(
                            (row.get("extra") or {}).get(key[2:], "") if key.startswith("x:") else row.get(key, ""),
                            secret_snapshot) for key, _heading in cols])
                    stream.flush()
                    os.fsync(stream.fileno())
                if cancel.is_set():
                    raise CancelledError("CSV export cancelled")
                os.replace(temporary, destination)
                temporary = None
                return len(snapshot)
            finally:
                if fd is not None:
                    os.close(fd)
                if temporary and os.path.exists(temporary):
                    os.unlink(temporary)

        def finished(result):
            self._export_cancels.discard(cancel)
            if self._closing:
                return
            if isinstance(result, BaseException):
                if not isinstance(result, CancelledError):
                    self._status_error(f"Export failed: {self.config.redact(result)}")
                return
            self.statusBar().showMessage(f"Exported {int(result):,} station(s) → {destination}")

        run_io(write_csv, finished, cancelled=cancel)

    def _import_favourites(self) -> None:
        import csv
        from pathlib import Path
        from PySide6.QtWidgets import QFileDialog
        from ..plugins.base import make_row
        path, _ = QFileDialog.getOpenFileName(self, "Import to Favorites", "", "CSV files (*.csv);;All files (*)")
        if not path:
            return
        if hasattr(self, "_import_cancel"):
            self._import_cancel.set()
        cancel = threading.Event()
        self._import_cancel = cancel
        bm = self.host.channels["bookmarks"]
        self._list_message("Reading station file…")
        def read():
            if Path(path).stat().st_size > MAX_IMPORT_BYTES:
                raise ValueError("CSV exceeds the import size limit")
            parsed, bad = [], 0
            with open(path, newline="", encoding="utf-8-sig") as stream:
                reader = csv.DictReader(stream)
                if "url" not in {(h or "").strip().lower() for h in reader.fieldnames or []}:
                    raise ValueError("The CSV needs a URL column")
                for index, values in enumerate(reader):
                    if cancel.is_set():
                        return None
                    if index >= MAX_ROWS:
                        raise ValueError("CSV has too many rows")
                    row = {(key or "").strip().lower(): (value or "").strip()
                           for key, value in values.items() if key and isinstance(value, str)}
                    if not valid_url(row.get("url"), token=True):
                        bad += 1
                        continue
                    bitrate = row.get("bitrate", "")
                    parsed.append(make_row(title=row.get("title") or row["url"], url=row["url"],
                                           genre=row.get("genre", ""), country=row.get("country", ""),
                                           homepage=row.get("homepage", ""),
                                           bitrate=int(bitrate) if bitrate.isdigit() else 0,
                                           format=row.get("format", "")))
            return parsed, bad, bm.prepare_import(parsed, [])
        def done(result, attempts=0):
            if self._closing or cancel.is_set():
                return
            if isinstance(result, BaseException):
                self._status_error(self.config.redact(result))
                return
            if result is None:
                return
            rows, bad, plan = result
            if not bm.plan_is_current(plan):
                if attempts >= 4:
                    self._status_error("Favorites changed during import; retry when editing is finished")
                    return
                run_io(lambda: (rows, bad, bm.prepare_import(rows, [])),
                       lambda outcome: done(outcome, attempts + 1), cancelled=cancel)
                return
            try:
                if not bm.apply_import_plan(plan):
                    self._status_error("Favorites changed during import; retry")
                    return
                added = plan.favorites_added
            except (ValueError, OSError) as exc:
                self._status_error(self.config.redact(exc))
                return
            self._cache.pop(("bookmarks", "Favorites"), None)
            if (self.current_channel, self.current_category) == ("bookmarks", "Favorites"):
                self._on_category(self.categories.currentItem(), None)
            self._list_message(f"Imported {added:,} favorites; {bad:,} invalid rows skipped")
        run_io(read, done, cancelled=cancel)


    def _refresh_favicon(self, cid: str) -> None:
        for p in self.config.icon_dir.glob(f"chan_{cid}.*"):
            try:
                p.unlink()
            except OSError:
                pass
        self._favicons.pop(cid, None)
        self._svc_icons.pop(cid, None)
        ch = self.host.channels.get(cid)
        from ..favicons import ensure_favicon
        run_io(lambda: ensure_favicon(self.config, ch),
               lambda path: self._on_favicon(cid, path))

    # ---- station favicons (artwork in the list; small lists only) ----
    def _station_icon(self, row):
        if self._icons_clearing or not self._station_favicons:  # no new icon work during a clear
            return self._service_icon_for(row)
        from PySide6.QtGui import QIcon
        fav = row.get("favicon")
        if fav:
            if fav in self._station_icons:
                ic = self._station_icons[fav]
                if isinstance(ic, QIcon):
                    self._station_icons.move_to_end(fav)
                    return ic
                if time.monotonic() >= self._icon_retry_at.get(("station", fav), float("inf")):
                    self._station_icons.pop(fav, None)
                    self._request_station_icon(fav)
            else:
                self._request_station_icon(fav)      # lazy: fetch on first paint (visible rows only)
        else:                                        # no directory favicon -> derive from the stream (if enabled)
            url = row.get("url")
            if url and self._stream_icons_on(row):
                if url in self._derived_icons:
                    ic = self._derived_icons[url]
                    if isinstance(ic, QIcon):
                        self._derived_icons.move_to_end(url)
                        return ic
                    if time.monotonic() >= self._icon_retry_at.get(("derived", url), float("inf")):
                        self._derived_icons.pop(url, None)
                        self._request_derived_icon(row)
                else:
                    self._request_derived_icon(row)
        return self._service_icon_for(row)           # service logo until a per-station icon arrives

    def _stream_icons_on(self, row) -> bool:
        """Whether to derive a per-station stream icon for this row's channel — Options -> Plugins ->
        'icons' (per service, default on). Off -> the channel just shows its service logo."""
        cid = row.get("_source") or self.current_channel
        return bool(self.config.get(f"stream_icons_{cid}", True))

    def _service_icon_for(self, row):
        """A station with no favicon of its own falls back to its source service's icon (e.g.
        Shoutcast stations show the Shoutcast logo). Built once per service from the cached
        channel favicon — one shared QIcon, so it costs nothing per row."""
        cid = row.get("_source") or self.current_channel
        if cid in self._svc_icons:
            return self._svc_icons[cid]
        icon = None
        path = self._favicons.get(cid)
        if path:
            from PySide6.QtGui import QIcon, QPixmap
            pm = QPixmap(path)
            if not pm.isNull():
                icon = QIcon(pm)
        self._svc_icons[cid] = icon
        return icon

    def _load_station_favicons(self) -> None:
        # Paint requests icons only for visible rows; never enqueue an entire category.
        self.table.viewport().update()

    def _request_station_icon(self, url: str) -> None:
        """Fetch one station's favicon (disk-cached -> once-only) and repaint when it arrives."""
        self._station_icons[url] = None              # mark in-flight (don't refetch / retry)
        from ..favicons import station_favicon
        self._trim_icons(self._station_icons)
        epoch = self._icon_epoch
        run_io(lambda: station_favicon(self.config, url),
               lambda path: self._on_station_favicon(url, path, epoch), cancelled=self._icon_cancel,
               priority=1, newest_first=True)             # after other work, and the rows on screen now first

    def _on_station_favicon(self, url, path, epoch=None) -> None:
        if self._closing or epoch is not None and epoch != self._icon_epoch:
            return
        if isinstance(path, str) and path:
            from PySide6.QtGui import QIcon
            ic = QIcon(path)
            if not ic.isNull():
                self._station_icons[url] = ic
                self._trim_icons(self._station_icons)
                self._icon_retry_at.pop(("station", url), None)
                self._icon_dirty.add(url)
                self._icon_refresh.start(150)        # debounce: one repaint per burst of loads

                return
        self._station_icons.pop(url, None)
        self._station_icons[url] = "retry"
        self._icon_failed("station", url, path)

    def _request_derived_icon(self, row) -> None:
        """For a station with no directory favicon (SHOUTcast/TuneIn), derive its broadcaster logo
        from the stream — resolve the .pls -> the ICY 'icy-url' homepage -> that site's favicon.
        Disk-cached + miss-marked so the slow round-trip runs once per station; lazy (visible rows)."""
        url = row.get("url")
        self._derived_icons[url] = None              # in-flight (don't re-request)
        from ..favicons import best_station_icon
        self._trim_icons(self._derived_icons)
        epoch = self._icon_epoch
        run_io(lambda r=dict(row): best_station_icon(self.config, r),
               lambda path: self._on_derived_icon(url, path, epoch), cancelled=self._icon_cancel)

    def _on_derived_icon(self, url, path, epoch=None) -> None:
        if self._closing or epoch is not None and epoch != self._icon_epoch:
            return
        if isinstance(path, str) and path:
            from PySide6.QtGui import QIcon
            ic = QIcon(path)
            if not ic.isNull():
                self._derived_icons[url] = ic
                self._trim_icons(self._derived_icons)
                self._icon_retry_at.pop(("derived", url), None)
                self._icon_dirty.add(url)
                self._icon_refresh.start(150)        # debounce: one repaint per burst
                return
        self._derived_icons[url] = "miss"
        self._icon_failed("derived", url, path)

    def _flush_icon_refresh(self) -> None:
        keys, self._icon_dirty = self._icon_dirty, set()
        self.model.refresh_icons(keys)            # only the rows whose icon arrived

    # ---- loading flow (all async through the airlock) ----
    def _on_channel(self, cur, _prev) -> None:
        if not cur or not cur.data(Qt.UserRole):
            return
        self._reset_load()
        self._cancel_pending_icons()
        self._next_channel_gen()
        self._load_gen += 1
        self._loading_key = None
        self.current_channel = cur.data(Qt.UserRole)
        self.current_category = ""
        self._sort_owner = None
        if self._nav.target and self._nav.target[0] != self.current_channel:
            self._nav.target = None
        self._view_search = False
        self._search_query = None
        self.search.clear()
        self.model.set_rows([])
        self._sync_extra_columns()               # the table and the Columns menu follow this feed at once,
        self._rebuild_columns_menu()             # not after its first list loads
        self._apply_field_filters()              # and so do this feed's field filters
        self.categories.clear()
        cid, generation = self.current_channel, self._channel_gen
        self._refresh_dot(cid)
        cached = self._cat_cache.get(cid)
        if cached:
            self._fill_categories(cid, cached)
            if time.monotonic() - self._cat_ages.get(cid, 0) > self._CACHE_STALE_S:
                self._fetch_categories(cid, generation, self.current_category)
        elif cid in self.INTERNAL_CHANNELS:
            self._fetch_categories(cid, generation)
        else:
            self.categories.addItem("Loading…")
            run_cache(lambda: self.config.cache_load(cid, "__categories__"),
                      lambda result: self._on_cached_categories(cid, generation, result))

    def _on_cached_categories(self, cid, generation, cached, view_generation=None) -> None:
        if self._closing or cid != self.current_channel or generation != self._channel_gen:
            return
        if view_generation is not None and view_generation != self._load_gen:
            return
        if isinstance(cached, tuple) and cached[0]:
            self._cat_cache[cid] = cached[0]
            self._cat_ages[cid] = time.monotonic() - cached[1]
            self._fill_categories(cid, cached[0])
            if cached[1] > self._CACHE_STALE_S:
                self._fetch_categories(cid, generation, self.current_category)
        else:
            self._fetch_categories(cid, generation)

    def _fetch_categories(self, cid, generation, preferred=None, fresh=False) -> None:
        operation = "refresh_categories" if fresh else "update_categories"
        cancel = self._cat_cancel        # a search or a category click must not cancel the list of categories itself
        run_async(lambda: self.host.call(cid, operation, timeout=45, cancel_event=cancel),
                  lambda result: self._on_categories(cid, result, generation, preferred, fresh),
                  cancelled=cancel)


    def _on_categories(self, cid: str, result, generation=None, preferred=None, fresh=False,
                       view_generation=None) -> None:
        if self._closing or cid != self.current_channel:
            return
        if generation is not None and generation != self._channel_gen:
            return
        if view_generation is not None and view_generation != self._load_gen:
            return
        self._refresh_dot(cid)
        if isinstance(result, Result) and result.ok and result.data:
            cats = list(result.data)
            unchanged = cats == self._cat_cache.get(cid) and self.categories.count() > 0
            self._cat_cache[cid] = cats
            self._cat_ages[cid] = time.monotonic()
            if cid not in self.INTERNAL_CHANNELS:
                cancel = self._cache_event(cid)
                run_cache(lambda: self.config.cache_save(cid, "__categories__", cats), lambda *_: None,
                          key=(cid, "__categories__"), cancelled=cancel)
            if not unchanged or fresh:
                derived = self.current_category == getattr(self.host.channels.get(cid), "listeners_category", None)
                preserve_view = (not fresh and bool(self.current_category)
                                 and (self.current_category in cats or derived)
                                 and self.categories.count() > 0)
                self._fill_categories(cid, cats,
                                      preferred=self.current_category if preserve_view else preferred,
                                      fresh=fresh, preserve_view=preserve_view)
        else:
            self._refreshing = False
            msg = result.message if isinstance(result, Result) else str(result)
            self._list_message(f"Showing saved stations — {cid}: {msg or 'No categories returned'}"
                               if self.model.rowCount() else f"Unable to load {cid}: {msg or 'No categories returned'}")
            self._retry_button.show()
            self._cancel_button.hide()

    def _fill_categories(self, cid: str, cats: list, preferred=None, fresh=False,
                         preserve_view=False) -> None:
        ch = self.host.channels.get(cid)
        cats = list(cats)
        if preferred is None and self._nav.target and self._nav.target[0] == cid:
            preferred = self._nav.target[1]           # going back or forward to a list of this feed
        if getattr(ch, "category_sort", True):
            pins = [c for c in getattr(ch, "category_pins", ()) if c in cats]
            cats = pins + sorted((c for c in cats if c not in pins), key=str.lower)
        lcat = getattr(ch, "listeners_category", "")
        if lcat:
            all_cat = getattr(ch, "all_category", "")
            cats = [c for c in cats if c != lcat]
            cats.insert(cats.index(all_cat) + 1 if all_cat in cats else len(cats), lcat)
        self.categories.blockSignals(True)
        try:
            self.categories.clear()
            self.categories.addItems(cats)
            self.categories.setCurrentRow(cats.index(preferred) if preferred in cats else 0)
        finally:
            self.categories.blockSignals(False)
        if not preserve_view:
            self._on_category(self.categories.currentItem(), None, fresh=fresh)

    def _on_category(self, cur, _prev, fresh=False) -> None:
        if self._closing or not cur or cur.text() == "Loading…":
            return
        self._reset_load()
        self._cancel_pending_icons()              # icons asked for the list just left are no use now
        self._view_search = False
        self._back_button.hide()
        self._search_query = None
        self.search.clear()
        self.current_category = cur.text()
        self._nav.visit(self.current_channel, self.current_category)
        self._nav_update()
        if self._sort_owner != self.current_channel:      # a new service starts with its default sort; the
            self._apply_default_sort()                    # categories of one service keep the sort the user chose
            self._sort_owner = self.current_channel
        cid, cat = self.current_channel, self.current_category
        self._load_gen += 1
        gen = self._load_gen
        self._loading_key = None
        if cat == getattr(self.host.channels.get(cid), "listeners_category", ""):
            self._show_listeners(cid, gen)
            return
        cached = None if fresh or cid in self.INTERNAL_CHANNELS else self._cache.get((cid, cat))
        if cached is not None:
            self._show_cached_rows(cid, cat, cached)
            if self._cache.age((cid, cat)) > self._CACHE_STALE_S:
                self._bg_refresh(cid, cat)
        elif fresh or cid in self.INTERNAL_CHANNELS:
            self._retain_during_load = bool(fresh and self._refresh_view_key == (cid, cat) and self.model.rowCount())
            self._begin_load(cid, cat, gen)
        else:
            self.model.set_rows([])
            self.statusBar().showMessage(f"Loading {cat}…")
            run_cache(lambda: self.config.cache_load(cid, cat),
                      lambda disk: self._on_cached_rows(cid, cat, gen, disk),
                      cancelled=self._load_cancel)      # a list passed over while arrowing down is never parsed

    def _on_cached_rows(self, cid, cat, gen, disk) -> None:
        if self._closing or gen != self._load_gen or cid != self.current_channel:
            return
        if isinstance(disk, CancelledError):
            return                                # the view moved on before this list was read
        if isinstance(disk, tuple):
            cached, age = disk
            admitted = self._cache.put((cid, cat), cached, age=age)
            self._update_cache_label()
            self._show_cached_rows(cid, cat, cached, merge_all=admitted)
            if age > self._CACHE_STALE_S:
                self._bg_refresh(cid, cat)
        else:
            self._begin_load(cid, cat, gen)

    def _show_cached_rows(self, cid, cat, cached, *, merge_all=True) -> None:
        rows = self._union(cid) if merge_all and self._is_all(cid, cat) else cached
        self.model.set_rows(rows, validated=True)
        self._apply_column_visibility()
        self._load_station_favicons()
        self._list_message(f"Loaded {len(rows):,} saved stations")

    def _begin_load(self, cid, cat, gen) -> None:
        self._load_started = False
        self._load_complete = True
        self._load_errors = []
        self._load_notes = []
        self._fresh_rows = []
        self._fresh_seen = set()
        self._pending_restore = None
        if not self._retain_during_load:
            self.model.set_rows([])
        self._list_message(f"Refreshing {cat} — showing saved stations" if self._retain_during_load
                           else f"Loading {cat}…")
        first = getattr(self.host.channels.get(cid), "page_size", None) or self.ALL_LIMIT
        self._load_page(cid, cat, 0, first, gen)


    def _apply_default_sort(self) -> None:
        """Apply the current channel's default table sort (Shoutcast → by listeners, descending),
        or clear sorting to the source order for channels that don't set one. The proxy keeps the
        order as rows stream in, so a progressively-loaded list stays sorted."""
        self._sync_extra_columns()
        ch = self.host.channels.get(self.current_channel)
        field = getattr(ch, "default_sort", "") if ch else ""
        if field:
            col = next((i for i, (_lbl, key) in enumerate(self.model.columns())
                        if key in (field, "x:" + field)), -1)
            if col >= 0:
                self.table.sortByColumn(col, Qt.DescendingOrder)
                return
        self.proxy.sort(-1)          # no per-channel default → natural (source/insertion) order
        self.table.horizontalHeader().setSortIndicator(-1, Qt.AscendingOrder)

    def _show_listeners(self, cid: str, gen: int) -> None:
        """The '★ With Listeners' view = the channel's All pool filtered to stations with a live
        listener count (>0). Reuses the loaded All data (instant); loads All first if needed."""
        ch = self.host.channels.get(cid)
        all_cat = getattr(ch, "all_category", "")
        if self._cache.get((cid, all_cat)) is not None:    # All already loaded -> filter now
            self._render_listeners(cid)
        else:                                              # need the full list first
            self.model.set_rows([])
            self.statusBar().showMessage("Loading the full list to find stations with listeners…")
            first = getattr(ch, "page_size", None) or self.ALL_LIMIT
            self._load_page(cid, all_cat, 0, first, gen)   # _finish_load filters when it completes

    def _render_listeners(self, cid: str, rows=None) -> None:
        rows = [r for r in (self._union(cid) if rows is None else rows)
                if (r.get("listeners") or 0) > 0]
        rows.sort(key=lambda r: r.get("listeners") or 0, reverse=True)
        self.model.set_rows(rows, validated=True)
        self._apply_column_visibility()
        self._load_station_favicons()
        self.statusBar().showMessage(f"{len(rows):,} stations with listeners")

    def _load_page(self, cid, cat, offset, limit, gen) -> None:
        self._loading_key = (cid, cat)
        self._cancel_button.show()
        search, cancel = self._search_query, self._load_cancel
        run_async(
            lambda: self.host.call(cid, "update_streams_page", cat, offset, limit, search,
                                   timeout=45, cancel_event=cancel),
            lambda result: self._on_page(cid, cat, offset, gen, result), cancelled=cancel)


    def _on_page(self, cid, cat, offset, gen, result) -> None:
        if self._closing or gen != self._load_gen or cid != self.current_channel:
            return
        self._refresh_dot(cid)
        ch = self.host.channels.get(cid)
        if not (isinstance(result, Result) and result.ok):
            retry = (gen, offset)
            busy = isinstance(result, Result) and "still running" in (result.message or "")
            if busy and self._busy_retries.get(retry, 0) < self._BUSY_RETRIES and self.host.is_enabled(cid):
                # The service still holds the requests of the categories just clicked past (they finish on their
                # own): ask again in a moment instead of making the user press Retry.
                self._busy_retries[retry] = self._busy_retries.get(retry, 0) + 1
                def ask_again():
                    if not self._closing and gen == self._load_gen and not self._load_cancel.is_set():
                        self._load_page(cid, cat, offset,
                                        (getattr(ch, "page_size", None) if offset == 0 else getattr(ch, "page_batch_size", None))
                                        or self.ALL_LIMIT, gen)
                QTimer.singleShot(500, ask_again)
                return
            if offset and retry not in self._page_retries and self.host.is_enabled(cid):
                self._page_retries.add(retry)
                self._list_message(f"Loaded {self.model.rowCount():,} stations; retrying next batch…")
                def again():
                    if not self._closing and gen == self._load_gen and not self._load_cancel.is_set():
                        self._load_page(cid, cat, offset,
                                        getattr(ch, "page_batch_size", None) or self.ALL_LIMIT, gen)
                QTimer.singleShot(1000, again)
                return
            self._loading_key = None
            self._cancel_button.hide()
            self._refreshing = False
            self._load_complete = False
            message = getattr(result, "message", str(result)) or "Request failed"
            self._list_message(f"Refresh failed; saved stations retained. {self.config.redact(message)}"
                               if self._retain_during_load else f"Incomplete list: {self.config.redact(message)}")
            self._retry_button.show()
            return
        rows = result.data or []
        self._load_complete &= bool(getattr(result, "complete", True))
        self._load_errors.extend(getattr(result, "errors", ()) or ())
        note = getattr(result, "message", "")
        if isinstance(note, str) and note and note != "no results" and note not in self._load_notes:
            self._load_notes.append(note)          # e.g. "2 row(s) rejected from <plugin>: …"
        known_before = len(self._fresh_rows) if self._retain_during_load else self.model.rowCount()
        if rows:
            if self._retain_during_load:
                for row in rows:
                    if row['url'] not in self._fresh_seen and len(self._fresh_rows) < self.ALL_LIMIT:
                        self._fresh_seen.add(row['url'])
                        self._fresh_rows.append(row)
                self._load_started = True
            elif offset == 0:
                self.model.set_rows(rows, validated=True)
                self._load_started = True
            else:
                remaining = self.ALL_LIMIT - self.model.rowCount()
                self.model.append_rows(rows[:max(0, remaining)], validated=True)
                if len(rows) > remaining:
                    self._load_complete = False
                    self._load_errors.append("Display limit reached; narrow the category or search")
                self._load_started = True
            self._apply_column_visibility()
        more, next_offset = self._page_continuation(ch, cat, offset, result)
        loaded_count = len(self._fresh_rows) if self._retain_during_load else self.model.rowCount()
        if more and offset and rows and loaded_count == known_before and loaded_count < self.ALL_LIMIT:
            more = False                                  # a page of rows that were all listed already: the service ignores the
            self._load_notes.append("Paging stopped: a page repeated stations already listed")  # offset, so end here
        if more and loaded_count < self.ALL_LIMIT:
            self._list_message(f"Refreshing: {loaded_count:,} stations received; showing saved stations"
                               if self._retain_during_load else f"Loaded {loaded_count:,} stations… loading more")
            self._load_page(cid, cat, next_offset,
                            getattr(ch, "page_batch_size", None) or getattr(ch, "page_size", None) or self.ALL_LIMIT, gen)
        else:
            if more:
                self._load_complete = False
            if not self._load_started and self._retain_during_load and self._load_complete:
                self.model.set_rows([])
            self._finish_load(cid, cat, ch)


    def _finish_load(self, cid, cat, ch) -> None:
        self._loading_key = None
        self._cancel_button.hide()
        self._refreshing = False
        complete = self._load_complete and not self._load_errors
        rows = list(self._fresh_rows) if self._retain_during_load else self.model.rows()
        if self._retain_during_load and complete:
            self._replace_rows(rows, validated=True)
        if self._view_search:
            self._list_message(f"{len(rows):,} results — {ch.title}: “{self._search_query}”"
                               + (" (partial; retry available)" if not complete else ""))
        elif complete:
            if cid not in self.INTERNAL_CHANNELS:
                self._cache[(cid, cat)] = rows
                self._save_catalog(cid, cat, rows)
            notes = (" " + " ".join(self._load_notes[:2])) if self._load_notes else ""
            self._list_message((f"Loaded {len(rows):,} stations from {ch.title}" if rows
                                else self._empty_message(cid, cat)) + notes)
        else:
            detail = self.config.redact("; ".join(self._load_errors[:3]))
            self._list_message(f"Partial list: {len(rows):,} stations. Saved complete list retained. {detail}")
        self._retry_button.setVisible(not complete)
        self._retain_during_load = False
        self._fresh_rows = []
        self._fresh_seen = set()
        self._pending_restore = None
        self._update_cache_label()
        self._load_station_favicons()
        if cat == getattr(ch, "all_category", "") and self.current_category == getattr(ch, "listeners_category", ""):
            self._render_listeners(cid, rows=rows if complete else None)


    def _is_all(self, cid: str, cat: str) -> bool:
        """Is `cat` this channel's 'everything' category (its view = the union pool)?"""
        ch = self.host.channels.get(cid)
        return bool(getattr(ch, "all_category", None)) and cat == ch.all_category

    def _union(self, cid):
        """A fresh complete All snapshot supersedes older category snapshots."""
        channel = self.host.channels.get(cid)
        all_key = (cid, getattr(channel, "all_category", None))
        cutoff = self._cache.timestamp(all_key)
        snapshots = [(self._cache.timestamp(key), values) for key, values in self._cache.items()
                     if key[0] == cid and self._cache.timestamp(key) >= cutoff]
        seen = {}
        for _stamp, values in sorted(snapshots, key=lambda item: item[0]):
            for row in values:
                if row.get("url"):
                    seen[row["url"]] = row
        return list(seen.values())

    def _saved_extra_keys(self, cid: str) -> set:
        """Extra-field names carried by the stations saved in Favorites (and history) or Local."""
        ch = self.host.channels.get(cid)
        rows = (list(getattr(ch, "favourite", []) or []) + list(getattr(ch, "history", []) or [])
                if cid == "bookmarks" else list(getattr(ch, "_rows", []) or []))
        keys: set = set()
        for row in rows:
            extra = row.get("extra") if isinstance(row, dict) else None
            if isinstance(extra, dict):
                keys.update(k for k in extra if isinstance(k, str))
        return keys

    def _channel_columns(self, cid: str) -> list:
        """Extra columns for the viewed channel. Favorites and Local hold stations from many services,
        so they offer the extras (of every enabled service) that their saved stations carry."""
        if cid in ("bookmarks", "local"):
            used = self._saved_extra_keys(cid)
            seen, out = set(), []
            for other in self.host.channels:
                if other in ("bookmarks", "local") or not self.host.is_enabled(other):
                    continue
                for item in self.host.columns_for(other):
                    if item[1] in used and item[1] not in seen and len(out) < 32:
                        seen.add(item[1])
                        out.append(item)
            return out
        return self.host.columns_for(cid) if cid and self.host.is_enabled(cid) else []

    def _extra_starts_hidden(self, cid: str) -> set:
        """Extra fields a service marks as secondary (off until ticked); Favorites/Local pool them."""
        if cid in ("bookmarks", "local"):
            return {k for other, ch in self.host.channels.items()
                    if other not in ("bookmarks", "local") and self.host.is_enabled(other)
                    for k in getattr(ch, "extra_columns_hidden", ()) if isinstance(k, str)}
        ch = self.host.channels.get(cid)
        return {k for k in getattr(ch, "extra_columns_hidden", ()) if isinstance(k, str)}

    def _sync_extra_columns(self, cid: str | None = None) -> bool:
        changed = self.model.set_extra_columns(self._channel_columns(cid or self.current_channel))
        if changed:
            self.table.reset_find_column()
            self._layout_applied = None
        return changed

    def _shown_extra(self, cid: str) -> set:
        shown = self.config.get("shown_extra_columns", {})
        keys = shown.get(cid, []) if isinstance(shown, dict) else []
        return {k for k in keys if isinstance(k, str)} if isinstance(keys, list) else set()

    def _hidden_extra(self, cid: str) -> set:
        hidden = self.config.get("hidden_extra_columns", {})
        keys = hidden.get(cid, []) if isinstance(hidden, dict) else []
        return {k for k in keys if isinstance(k, str)} if isinstance(keys, list) else set()

    def _default_hidden(self) -> frozenset:
        """Fields that start off. Source is useful where services mix, so those lists show it."""
        if self.current_channel in ("bookmarks", "local") or self._search_active():
            return DEFAULT_HIDDEN - {"source"}
        return DEFAULT_HIDDEN

    def _search_active(self) -> bool:
        """Showing results from every service at once (Search scope: all services)."""
        return bool(getattr(self, "_view_search", False)) and self.search_scope.currentIndex() == 2

    def _column_wanted(self, field: str) -> bool:
        """Is this field switched on (before checking that the list has any data for it)?"""
        if field.startswith("x:"):
            key, cid = field[2:], self.current_channel
            if key in self._extra_starts_hidden(cid):        # secondary field: shown only once ticked
                return key in self._shown_extra(cid)
            return key not in self._hidden_extra(cid)
        if field == "title":
            return True
        offered = self._offered_builtins()
        if offered is not None and field not in offered:     # this feed never supplies it
            return False
        own = self._overrides(self.current_channel)
        if own is not None:                       # this feed has its own choices
            return own.get(field, field not in self._default_hidden())
        preferred = self.config.get("visible_columns", [])     # an older, global choice seeds feeds not yet customised
        if preferred:
            return field in preferred
        return field not in self._default_hidden()

    def _overrides(self, cid: str):
        """This feed's own on/off choices for built-in fields ({} = defaults), or None if never customised."""
        every = self.config.get("column_overrides", {})
        own = every.get(cid) if isinstance(every, dict) else None
        return {k: v for k, v in own.items() if isinstance(k, str) and isinstance(v, bool)} if isinstance(own, dict) else None

    def _rebuild_columns_menu(self) -> None:
        menu = self._columns_menu
        if menu.isVisible():                        # never rebuild under the user's cursor
            return
        columns = self._feed_columns()
        loaded = bool(self.model.rowCount())     # with nothing loaded yet we cannot say a field is empty
        sig = tuple((field, self._column_wanted(field), (not loaded) or self.model.has_field(field))
                    for _label, field in columns)
        feed = self._feed_title()
        if (sig, feed) == self._columns_sig and menu.actions():
            return
        self._columns_sig = (sig, feed)
        menu.clear()                                # also deletes the old actions
        self._column_actions = {}
        menu.setToolTipsVisible(True)
        heading = QAction(f"Fields for {feed}", menu)
        heading.setEnabled(False)
        menu.addAction(heading)
        for (label, field), (_f, wanted, has_data) in zip(columns, sig):
            action = QAction(label if has_data or field == "title" else f"{label}   · none here", menu, checkable=True)
            action.setChecked(wanted)
            action.setEnabled(field != "title")
            if field.startswith("x:"):
                action.setToolTip("Added by this service")
            elif not has_data:
                action.setToolTip("This list has no values for this field yet")
            action.toggled.connect(lambda on, name=field: self._set_column_visible(name, on))
            menu.addAction(action)
            self._column_actions[field] = action
        menu.addSeparator()
        menu.addAction(QAction("Fields window…   drag to reorder", menu, triggered=self._open_columns_panel))
        menu.addAction(QAction("Fit columns to contents", menu, triggered=self._fit_columns))
        menu.addAction(QAction(f"Reset {feed} to defaults", menu, triggered=self._reset_columns))
        self._refresh_columns_panel()

    _ALWAYS_OFFERED = frozenset({"title", "url", "listformat", "source"})

    def _offered_builtins(self):
        """Built-in fields offered for the viewed feed, or None for all (Favorites, Local, all-service
        search, and plugins that don't say what they supply)."""
        cid = self.current_channel
        if cid in ("bookmarks", "local") or self._search_active():
            return None
        declared = self.host.fields_for(cid)
        return None if declared is None else self._ALWAYS_OFFERED | set(declared)

    def _feed_columns(self) -> list:
        """Every field this feed can show: the built-ins it supplies plus the extras it declares."""
        offered = self._offered_builtins()
        return ([c for c in COLUMNS if offered is None or c[1] in offered]
                + [(label, "x:" + key) for label, key, _kind in self._channel_columns(self.current_channel)])

    def _feed_title(self) -> str:
        ch = self.host.channels.get(self.current_channel)
        return (ch.title if ch else "") or "this list"

    def _open_columns_panel(self) -> None:
        from PySide6.QtCore import QPoint
        from .columnspanel import ColumnsPanel
        first = self._columns_panel is None
        if first:
            self._columns_panel = ColumnsPanel(self)
        panel = self._columns_panel
        panel.refresh()
        if first:
            panel.move(self.mapToGlobal(QPoint(max(0, self.width() - panel.width() - 40), 150)))
        panel.show()
        panel.raise_()
        panel.activateWindow()

    def _refresh_columns_panel(self) -> None:
        if self._columns_panel is not None and self._columns_panel.isVisible():
            self._columns_panel.refresh()

    def _panel_fields(self) -> list:
        """[(label, field, shown, has_data)] for the feed being viewed, in the table's current column order."""
        feed = self._feed_columns()
        labels = {field: label for label, field in feed}
        model_fields = [field for _label, field in self.model.columns()]
        hdr = self.table.horizontalHeader()
        if hdr.count() == len(model_fields) and set(labels) <= set(model_fields):
            order = sorted((f for f in model_fields if f in labels), key=lambda f: hdr.visualIndex(model_fields.index(f)))
        else:
            order = [field for _label, field in feed]
        loaded = bool(self.model.rowCount())
        return [(labels[f], f, self._column_wanted(f), (not loaded) or self.model.has_field(f)) for f in order]

    # ---- per-field filters (Fields window) ----
    def _field_filter(self, field: str) -> dict | None:
        return (self._field_filters.get(self.current_channel) or {}).get(field)

    def _any_field_filter(self) -> bool:
        return bool(self._field_filters.get(self.current_channel))

    def _set_field_filter(self, field: str, spec: dict | None) -> None:
        cid = self.current_channel
        if not cid:
            return
        spec = clean_spec(field_kind(self.model, field), spec)
        filters = self._field_filters.setdefault(cid, {})
        if spec:
            filters[field] = spec
        else:
            filters.pop(field, None)
        if not filters:
            self._field_filters.pop(cid, None)
        self._apply_field_filters()
        if self.model.rowCount():
            self.statusBar().showMessage(
                f"Filters: {self.proxy.rowCount():,} of {self.model.rowCount():,} stations shown", 5000)

    def _clear_field_filters(self) -> None:
        self._field_filters.pop(self.current_channel, None)
        self._apply_field_filters()

    def _apply_field_filters(self) -> None:
        """Give the table the filters of the feed on screen and mark filtered feeds in the sidebar."""
        self.proxy.set_field_filters(self._field_filters.get(self.current_channel) or {})
        for i in range(self.channels.count()):
            item = self.channels.item(i)
            cid = item.data(Qt.UserRole)
            if not cid or cid not in self.host.channels:
                continue
            title = self.host.channels[cid].title
            item.setText(f"{title}  · filtered" if self._field_filters.get(cid) else title)

    def _set_column_order(self, order: list) -> None:
        """Put the columns in this field order (the Fields window's drag and drop)."""
        model_fields = [field for _label, field in self.model.columns()]
        hdr = self.table.horizontalHeader()
        if hdr.count() != len(model_fields):
            return
        for visual, field in enumerate(f for f in order if f in model_fields):
            hdr.moveSection(hdr.visualIndex(model_fields.index(field)), visual)

    def _header_menu(self, pos) -> None:
        self._columns_menu.exec(self.table.horizontalHeader().mapToGlobal(pos))

    def _reset_columns(self) -> None:
        """Back to the defaults for the feed being viewed; other feeds keep their own choices."""
        cid = self.current_channel
        self._store_for_feed("column_overrides", cid, {})        # {} = customised-but-default (ignores the old global list)
        self._store_for_feed("hidden_extra_columns", cid, None)
        self._store_for_feed("shown_extra_columns", cid, None)
        self._store_for_feed("column_layout", cid, None)
        self.config.save_settings()
        self._layout_applied = None
        self._apply_column_visibility()
        self.statusBar().showMessage(f"{self._feed_title()}: fields reset to defaults", 3000)

    def _store_for_feed(self, key: str, cid: str, value) -> None:
        """Set (or, with None, remove) one feed's entry in a per-feed settings dict."""
        every = self.config.get(key, {})
        every = dict(every) if isinstance(every, dict) else {}
        if value is None:
            every.pop(cid, None)
        else:
            every[cid] = value
        self.config.set(key, every)

    def _fit_columns(self) -> None:
        hdr = self.table.horizontalHeader()
        for col in range(hdr.count()):
            if not hdr.isSectionHidden(col):
                self.table.resizeColumnToContents(col)
                self.table.setColumnWidth(col, max(48, min(self.table.columnWidth(col) + 6, 460)))
        self.statusBar().showMessage("Columns fitted to their contents", 3000)

    def _source_label(self, row: dict) -> str:
        src = self._resolve_source(row)
        if src == "bookmarks" and not row.get("_source"):
            return ""                              # an old entry that never recorded its service
        ch = self.host.channels.get(src)
        return ch.title if ch else ""

    def _apply_column_visibility(self) -> None:
        self._sync_extra_columns()
        if not self.model.rowCount():
            self._rebuild_columns_menu()          # the field list still follows the feed being viewed
            return
        self._layout_applying = True
        try:
            for col, (_label, field) in enumerate(self.model.columns()):
                self.table.setColumnHidden(col, not (self.model.has_field(field) and self._column_wanted(field)))
            self._apply_column_layout()
        finally:
            self._layout_applying = False
        self._rebuild_columns_menu()

    # ---- remembered widths and order, by field name (so they survive switching services) ----
    def _stored_layout(self) -> dict:
        every = self.config.get("column_layout", {})
        own = every.get(self.current_channel) if isinstance(every, dict) else None
        return own if isinstance(own, dict) else {}

    def _apply_column_layout(self) -> None:
        fields = [field for _label, field in self.model.columns()]
        signature = (self.current_channel, tuple(fields))
        if self._layout_applied == signature:
            return
        self._layout_applied = signature
        stored = self._stored_layout()
        widths = stored.get("widths") if isinstance(stored.get("widths"), dict) else {}
        order = stored.get("order") if isinstance(stored.get("order"), list) else []
        hdr = self.table.horizontalHeader()
        wanted = [f for f in order if f in fields] + [f for f in fields if f not in order]
        for visual, field in enumerate(wanted):
            hdr.moveSection(hdr.visualIndex(fields.index(field)), visual)
        for col, field in enumerate(fields):
            width = widths.get(field)
            width = width if isinstance(width, int) and 24 <= width <= 2000 else DEFAULT_WIDTHS.get(field, DEFAULT_WIDTH)
            if not hdr.isSectionHidden(col):
                hdr.resizeSection(col, width)

    def _column_layout_changed(self, *_args) -> None:
        if not self._layout_applying:
            self._layout_timer.start()

    def _save_column_layout(self) -> None:
        fields = [field for _label, field in self.model.columns()]
        hdr = self.table.horizontalHeader()
        if not fields or hdr.count() != len(fields) or self._layout_applied != (self.current_channel, tuple(fields)):
            return
        stored = self._stored_layout()
        widths = dict(stored.get("widths") or {}) if isinstance(stored.get("widths"), dict) else {}
        last = next((hdr.logicalIndex(v) for v in range(hdr.count() - 1, -1, -1)
                     if not hdr.isSectionHidden(hdr.logicalIndex(v))), -1)
        for col, field in enumerate(fields):
            if col != last and not hdr.isSectionHidden(col):      # the last column is stretched, not sized
                widths[field] = hdr.sectionSize(col)
        shown = [fields[hdr.logicalIndex(v)] for v in range(hdr.count())]
        old = stored.get("order") if isinstance(stored.get("order"), list) else []
        order = shown + [f for f in old if f not in shown]
        layout = {"widths": widths, "order": order}
        if layout != stored:
            self._store_for_feed("column_layout", self.current_channel, layout)
            self.config.save_settings()


    def _selected_row(self) -> dict | None:
        idx = self.table.currentIndex()
        if not idx.isValid():
            return None
        return self.model.row_at(self.proxy.mapToSource(idx).row())

    def _on_station_clicked(self, index) -> None:
        # selecting a station shows its details (name · bitrate/codec · URL) in the status bar
        row = self.model.row_at(self.proxy.mapToSource(index).row())
        if not row:
            return
        parts = [row["title"]]
        if row.get("bitrate"):
            parts.append(f"{row['bitrate']}k {row.get('format', '').replace('audio/', '')}".strip())
        if row.get("url"):
            parts.append(row["url"])
        self.statusBar().showMessage("  ·  ".join(parts))

    def _station_menu(self, pos) -> None:
        idx = self.table.indexAt(pos)
        row = self.model.row_at(self.proxy.mapToSource(idx).row()) if idx.isValid() else None
        if not row:                                   # empty space below the rows: just the field chooser
            self._columns_menu.exec(self.table.viewport().mapToGlobal(pos))
            return
        row = dict(row)
        row.setdefault("_source", self._resolve_source(row))
        from PySide6.QtWidgets import QApplication, QMenu
        menu = QMenu(self)
        menu.addAction("Play", lambda: self._play_row(row))
        bm = self.host.channels.get("bookmarks")
        fav = bool(bm and bm.is_favourite(row.get("url", "")))
        menu.addAction("Remove favorite" if fav else "★ Favorite",
                       lambda: self._toggle_favourite_row(row))
        if self.current_channel == "local":
            menu.addAction("Remove from Local", lambda: self._remove_local_row(row))
        menu.addSeparator()
        menu.addAction("Copy URL", lambda: QApplication.clipboard().setText(copy_url(row.get("url", ""))))
        song = clean_icy_title(str(row.get("playing") or ""))
        if song:
            menu.addAction("Copy song", lambda: QApplication.clipboard().setText(song))     # what the station plays now
        self._add_web_search(menu, row)
        menu.addAction("Info…", lambda: self._station_info(row))
        menu.addAction("Recache icon", lambda: self._recache_station_icon(row))
        if row.get("homepage"):
            menu.addAction("Open Website",
                           lambda: self._open_website(row["homepage"]))
        menu.addSeparator()
        self._rebuild_columns_menu()
        menu.addMenu(self._columns_menu)              # choose the fields for this feed
        try:
            menu.exec(self.table.viewport().mapToGlobal(pos))
        finally:
            menu.deleteLater()

    def _add_web_search(self, menu, row: dict, song: str | None = None) -> None:
        """'Search the web for this song' (when a song is known, first) and '... this station' (always)."""
        from ..websearch import open_search, song_of, station_of
        song = song_of(row) if song is None else song
        name = station_of(row)
        if song:
            menu.addAction("Search the web for this song", lambda: open_search(song))
        if name:
            menu.addAction("Search the web for this station", lambda: open_search(name))

    def _station_info(self, row: dict) -> None:
        from .dialogs import station_info
        labels = {field[2:]: label for label, field in self.model.columns() if field.startswith("x:")}
        types = {field[2:]: self.model.column_type(field) for _label, field in self.model.columns()
                 if field.startswith("x:")}
        station_info(self, self.config.get("theme", "dark"), row, extra_labels=labels, extra_types=types)

    def _nowplaying_menu(self, pos) -> None:
        """Right-click the now-playing text on the player bar: copy the track / stream URL, station
        info, open the broadcaster's site — all acting on the row that's actually streaming."""
        row = self._playing_row
        if not row:
            return                                   # nothing playing -> no menu
        from PySide6.QtWidgets import QApplication, QMenu
        menu = QMenu(self)
        fav_row = dict(row)
        fav_row.setdefault("_source", self._resolve_source(fav_row))
        bm = self.host.channels.get("bookmarks")
        if bm and fav_row.get("url"):
            is_fav = bool(bm.is_favourite(fav_row["url"]))
            menu.addAction("Remove favorite" if is_fav else "★ Favorite", lambda: self._toggle_favourite_row(fav_row))
            menu.addSeparator()
        track = clean_icy_title(self._np_full or "")
        if track:
            menu.addAction("Copy playing track", lambda: QApplication.clipboard().setText(track))
        menu.addAction("Copy URL", lambda: QApplication.clipboard().setText(copy_url(row.get("url", ""))))
        self._add_web_search(menu, row, song=track)
        menu.addSeparator()
        menu.addAction("Info…", lambda: self._station_info(row))
        if row.get("homepage"):
            menu.addAction("Open Website", lambda: self._open_website(row["homepage"]))
        try:
            menu.exec(self.np_label.mapToGlobal(pos))
        finally:
            menu.deleteLater()

    def _recache_station_icon(self, row: dict) -> None:
        """Force-refresh this station's art-box icon: clear its cached files and re-fetch the
        best logo (prefers the broadcaster's apple-touch-icon). Reports the result + pixel size."""
        title = row.get("title", "station")
        self.statusBar().showMessage(f"Re-caching icon for {title}…")
        from ..favicons import best_station_icon
        run_io(lambda r=dict(row): best_station_icon(self.config, r, refetch=True),
               lambda path, r=dict(row): self._after_recache(r, path))

    def _after_recache(self, row: dict, path) -> None:
        if self._closing:
            return
        from PySide6.QtGui import QIcon, QPixmap
        title = row.get("title", "station")
        if isinstance(path, str) and path:
            pm = QPixmap(path)
            sz = f"{pm.width()}×{pm.height()}" if not pm.isNull() else "?"
            fav = row.get("favicon", "")
            if fav and not pm.isNull():                       # refresh the list row's icon too
                self._station_icons[fav] = QIcon(path)
                self._icon_dirty.add(fav)
                self._icon_refresh.start(50)
            if self._playing_row and self._playing_row.get("url") == row.get("url"):
                self._art_token = self._playing_row.get("url", "")
                self._apply_art(self._art_token, path)        # update the now-playing box live
            self.statusBar().showMessage(f"Re-cached icon for {title}  ({sz})")
        else:
            self.statusBar().showMessage(f"No broadcaster logo found for {title}")

    def _play_selected(self, *_a) -> None:
        row = self._selected_row() or self._last_row
        if row:
            self._play_row(row)
            return
        self.btn_play.setChecked(bool(self.player.is_playing))      # nothing started: the button must not say it did
        self.statusBar().showMessage("Select a station to play", 4000)

    def _play_refused(self, message: str) -> None:
        """A station that cannot be played: say so, and make the button, the label and the pending flag
        show that nothing is playing (they were set the moment Play was pressed)."""
        self._pending_play = False
        self._status_error(message)
        self.btn_play.setChecked(bool(self.player.is_playing))
        self.np_label.setText(self._np_full if self.player.is_playing else "Can't play this station")

    def _space_pressed(self) -> None:
        """Space: play or pause as before, except that with another station selected than the one playing,
        and the list focused, it switches to the selected one (one press, not stop and then play)."""
        row = self._selected_row()
        playing = self._playing_row or {}
        if (row and self.btn_play.isChecked() and playing.get("url") and row.get("url") != playing.get("url")
                and self.table.hasFocus()):
            self._play_row(row)
        else:
            self._toggle_play()

    def _play_row(self, row) -> None:
        if isinstance(row, dict):
            origin = self.host.channels.get(self._resolve_source(row))
            local = bool(getattr(origin, "local_files", False))   # a plugin that opted in may play file:// stations
        else:
            local = False
        row = station_row(row, local=local)
        if row is None:
            self._play_refused("Unsupported station URL")
            return
        if not self._retrying:                               # the user chose a station: any waiting retry is theirs no more
            self._retry_token += 1
            self._retry_pending = False
            self._stream_retries = 0
        self._play_cancel.set()
        self._play_cancel = threading.Event()
        cancel = self._play_cancel
        self._play_gen += 1
        self._pending_play = True
        self.btn_play.setChecked(True)
        self.act_stop.setEnabled(True)
        generation = self._play_gen
        src = self._resolve_source(row)
        row.setdefault("_source", src)
        ch = self.host.channels.get(src)
        if ch is not None and getattr(ch, "needs_resolve", False):
            self.np_label.setText(f"Resolving {row['title']}…")
            run_playback(lambda: self.host.call(src, "resolve_url", row, cancel_event=cancel, playback=True),
                         lambda res: self._start_playback(row, res, generation), cancelled=cancel)
        else:
            self._start_playback(row, None, generation)


    def _resolve_source(self, row: dict) -> str:
        """Which channel resolves this row's URL: its origin if known (favourites/history
        remember it), else the current channel — with a fallback for legacy TuneIn links."""
        if row.get("url", "").startswith("audioaddict://"):
            return "audioaddict"
        src = row.get("_source")
        if src and src in self.host.channels:
            return src
        if "opml.radiotime.com" in row.get("url", "") and "tunein" in self.host.channels:
            return "tunein"
        return self.current_channel

    def _start_playback(self, row: dict, resolved, generation=None) -> None:
        if self._closing or (generation is not None and generation != self._play_gen):
            return
        self._pending_play = False
        origin = self.host.channels.get(self._resolve_source(row))
        local = bool(getattr(origin, "local_files", False))   # plugin opted in to file:// stations
        row = station_row(row, local=local)
        if row is None:
            self._play_refused("Unsupported or invalid station URL")
            return
        if resolved is not None:
            if not isinstance(resolved, Result) or not resolved.ok or not isinstance(resolved.data, dict):
                self._status_error(self.config.redact(getattr(resolved, "message", "Unable to resolve station")))
                self.btn_play.setChecked(bool(self.player.is_playing))
                self.np_label.setText(self._np_full if self.player.is_playing else "Connection failed")
                return
            url = resolved.data.get("url")
        else:
            url = row["url"]
        if not valid_url(url, local=local):
            self._play_refused("This station did not resolve to a supported network stream")
            return
        self.player.preroll_secs = int(self.config.get("stream_preroll_secs", 0) or 0)
        if not (self.player.play(url, local=True) if local else self.player.play(url)):
            self._status_error(self.config.redact(self.player.error or "Audio playback is unavailable"))
            self.btn_play.setChecked(bool(self.player.is_playing))
            return
        self._play_started_at = time.monotonic()
        self._playing_bitrate = row.get("bitrate", 0)
        self._playing_row_url = row["url"]
        self._np_full = row["title"]
        self._np_meta = ""
        self._elide_np()
        self._playing_row = row
        self._last_row = row
        self._update_art()
        self.btn_play.setChecked(True)
        self.act_play.setEnabled(True)
        bm = self.host.channels.get("bookmarks")
        if bm:
            hist = dict(row)
            hist.setdefault("_source", self._resolve_source(row))
            try:
                bm.add_history(hist)
            except (ValueError, OSError) as exc:
                self._status_error(self.config.redact(exc))
            self._cache.pop(("bookmarks", "History"), None)
            if self.current_channel == "bookmarks" and self.current_category == "History":
                self._replace_rows(bm.update_streams("History"))
        self.act_fav.setChecked(bool(bm and bm.is_favourite(row["url"])))
        self.np_label.setText(f"Connecting — {row['title']}")
        self.statusBar().showMessage(f"Connecting to {row['title']}")
        self._sync_visualizer()
        self._last_notified_title = ""
        self._notify(row["title"], row.get("genre") or row.get("description") or "Now playing", row)
        self._discord_update(row["title"], row.get("genre") or "Internet radio", reset=True)

    def _toggle_play(self, checked=None) -> None:
        play = not self.btn_play.isChecked() if checked is None else bool(checked)
        if play:
            self._play_selected()
        else:
            self._stop()

    def _toggle_normalize(self, on) -> None:
        """Loudness normalization on/off — applies the mpv filter live, persists, and keeps the
        player-bar button and the Playback menu item in sync (echo-guarded)."""
        on = bool(on)
        if on == self._normalize:
            return                               # already there (ignores the button<->menu echo)
        self._normalize = on
        self.player.set_normalize(on)
        self.config.set("normalize", on)
        self.config.save_settings()
        for wdg in (getattr(self, "btn_norm", None), getattr(self, "act_normalize", None)):
            if wdg is not None:
                wdg.blockSignals(True)
                wdg.setChecked(on)
                wdg.blockSignals(False)
        self.statusBar().showMessage("Loudness normalization " + ("on" if on else "off"))

    def _retry_dropped_stream(self) -> bool:
        """A network stream ended by itself (a blip, a sleep and resume): try the same station again after
        2, 4, 8, 15 and 30 seconds before giving up. True while a try is under way or waiting; False when it
        is not worth trying (a local file that ended, or the tries are used up)."""
        if self._retry_pending:
            return True
        url = str((self._playing_row or {}).get("url", ""))
        if not url.startswith(("http://", "https://", "icy://", "mmsh://")):
            return False
        if self._stream_retries >= len(self._STREAM_RETRY_DELAYS_MS):
            self._stream_retries = 0
            return False
        delay = self._STREAM_RETRY_DELAYS_MS[self._stream_retries]
        self._stream_retries += 1
        self._retry_pending = True
        self._retry_token += 1
        token, row = self._retry_token, self._playing_row
        self.statusBar().showMessage(
            f"Stream interrupted — trying again ({self._stream_retries} of {len(self._STREAM_RETRY_DELAYS_MS)})…", 6000)
        self.np_label.setText(f"Reconnecting — {self._np_full}")
        QTimer.singleShot(delay, lambda: self._retry_play(row, token))
        return True

    def _retry_play(self, row, token) -> None:
        self._retry_pending = False
        if token != self._retry_token or self._closing or not self.btn_play.isChecked() or row is None:
            return                                           # stopped, or another station started meanwhile
        self._retrying = True
        try:
            self._play_row(row)
        finally:
            self._retrying = False

    def _stop(self, *_a) -> None:
        self._retry_token += 1                               # a try that is waiting must not start the sound later
        self._retry_pending = False
        self._stream_retries = 0
        self._play_gen += 1
        self._play_cancel.set()
        self._pending_play = False
        self.player.stop()
        self._playing_row_url = ""
        self.btn_play.setChecked(False)
        self.np_label.setText("Stopped")
        self._update_tray_np("")
        self._np_meta = ""
        self._last_notified_title = ""
        self._discord_clear()
        self._playing_row = None
        self._update_art()
        self.statusBar().showMessage("Stopped")
        self._sync_visualizer()

    def _drop_row_from_view(self, url: str) -> None:
        """Remove one station from the list on screen without losing the scroll place; the next row is selected."""
        current = self.table.currentIndex()
        at = current.row() if current.isValid() else -1
        self._replace_rows([r for r in self.model.rows() if r.get("url") != url], validated=True)
        count = self.proxy.rowCount()
        if at >= 0 and count:
            self.table.setCurrentIndex(self.proxy.index(min(at, count - 1), 0))

    def _remove_local_row(self, row) -> None:
        """Take a station out of the Local list (the list a user fills by hand and could not empty before)."""
        local = self.host.channels.get("local")
        url = (row or {}).get("url", "")
        if local is None or not url:
            return
        try:
            local.remove(url)
        except (OSError, ValueError) as exc:
            self._status_error(self.config.redact(exc))
            return
        self._cache.pop(("local", self.current_category), None)
        if self.current_channel == "local":
            self._drop_row_from_view(url)
        self.statusBar().showMessage("Removed from Local: " + str(row.get("title", url)))

    def _delete_selected(self) -> bool:
        """Delete in the station list: removes the selected station from Local, or from Favorites."""
        row = self._selected_row()
        if not row:
            return False
        if self.current_channel == "local":
            self._remove_local_row(row)
            return True
        if self.current_channel == "bookmarks" and self.current_category == "Favorites":
            self._toggle_favourite_row(row)
            return True
        return False

    def _toggle_favourite(self, *_a) -> None:
        self._toggle_favourite_row(self._selected_row())

    def _toggle_favourite_row(self, row) -> None:
        bm = self.host.channels.get("bookmarks")
        if not row or not bm:
            return
        row = dict(row)
        row.setdefault("_source", self.current_channel)   # remember origin (for resolving on play)
        try:
            now = bm.toggle(row)
        except (OSError, ValueError) as exc:
            self._status_error(self.config.redact(exc))
            return
        self._sync_selection_actions()
        self._cache.pop(("bookmarks", "Favorites"), None)   # the favourites list changed -> stale cache
        if self.current_channel == "bookmarks" and self.current_category == "Favorites" and not now:
            url = row.get("url", "")                          # viewing the list we just edited ->
            self._drop_row_from_view(url)                     # drop the row now, keep the place in the list
            self.statusBar().showMessage("Removed from Favorites: " + row["title"])
        else:
            self.model.refresh_icons({row.get("url", "")})   # elsewhere: just flip the ★ marker of that row in place
            self.statusBar().showMessage(("Favorited " if now else "Unfavorited ") + row["title"])
        if now and not row.get("favicon"):   # icon-less station -> derive its real favicon (background)
            from ..favicons import derive_station_favicon_url
            url = row.get("url", "")
            run_io(lambda: derive_station_favicon_url(row),
                   lambda favurl, u=url: self._on_derived_favicon(u, favurl), priority=1, newest_first=True)

    def _on_derived_favicon(self, station_url: str, favurl) -> None:
        if self._closing:
            return
        bm = self.host.channels.get("bookmarks")
        if favurl and bm:
            bm.set_favicon(station_url, favurl)   # stamp it on the saved favourite (shows next view)

    def _notify(self, title: str, message: str, row: dict | None) -> None:
        """Fire an OS desktop notification via the system tray. No-op when notifications are off
        or there's no tray host that supports messages (e.g. a bare WM). Never raises."""
        if not self._notifications:
            return
        tray = getattr(self, "_tray", None)
        if tray is None or not tray.supportsMessages():
            return
        try:
            from PySide6.QtWidgets import QSystemTrayIcon
            icon = self._notify_icon(row)
            if icon is not None and not icon.isNull():
                tray.showMessage(title, message, icon, 5000)
            else:
                tray.showMessage(title, message, QSystemTrayIcon.MessageIcon.Information, 5000)
        except Exception:  # noqa: BLE001 — a notification must never disrupt playback
            pass

    def _notify_icon(self, row):
        """Best icon for a notification: the now-playing art if it's up (per-station/broadcaster
        logo), else the source service's logo, else the window icon."""
        from PySide6.QtGui import QIcon
        if self._show_art and not self.art.isHidden():
            pm = self.art.pixmap()
            if pm is not None and not pm.isNull():
                return QIcon(pm)
        sp = self._service_pixmap(row) if row else None
        return QIcon(sp) if (sp is not None and not sp.isNull()) else self.windowIcon()

    def _on_nowplaying(self, title: str) -> None:
        if self._closing or not self._playing_row or not self.player.is_playing:
            return
        title = self.config.redact(title)
        if title:
            self._np_full = title
            self._elide_np()
            self.model.set_playing(self._playing_row_url, title)   # keep the table cell in sync
            self._log_song(title)
            self._update_tray_np(title)
            self._discord_update(title, (self._playing_row or {}).get("title", ""))   # track / station
            if title != self._last_notified_title:                 # track changed -> notify (de-duped)
                self._last_notified_title = title
                self._notify(title, (self._playing_row or {}).get("title", ""), self._playing_row)

    def _log_song(self, song: str) -> None:
        """Record a played track, with the time heard, in the saved song history (View → Song history)."""
        song = clean_icy_title(song or "")     # strip iHeart-style metadata blobs before storing
        if not song:
            return
        row = self._playing_row or {}
        station = row.get("title", "")
        ch = self.host.channels.get(row.get("_source") or self.current_channel)
        service = ch.title if ch else ""
        keep = {k: row[k] for k in ("title", "url", "_source") if row.get(k)}
        entry = self._song_history.add(song, station, service, keep or None)
        if entry is not None and self._song_window is not None:
            self._song_window.changed()

    def _song_history_dialog(self) -> None:
        """Open the Song History window (one of a kind: an open one is brought forward)."""
        from .songwindow import SongHistoryWindow
        window = self._song_window
        if window is None:
            window = self._song_window = SongHistoryWindow(self, self._song_history)
        window.show()
        window.raise_()
        window.activateWindow()

    def _elide_np(self) -> None:
        fm = QFontMetrics(self.np_label.font())
        meta = f"   -   {self._np_meta}" if self._np_meta else ""
        avail = max(120, self.np_label.width())
        title = fm.elidedText(self._np_full, Qt.ElideRight, max(40, avail - fm.horizontalAdvance(meta)))
        self.np_label.setTextFormat(Qt.PlainText)
        self.np_label.setText(title + meta)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if getattr(self, "spectro", None) is not None:
            self.spectro.reset_width()    # window resized -> spectrogram back to its normal width
        if self._np_full:
            self._elide_np()

    # ---- misc actions ----
    def _build_colors_menu(self) -> None:
        from PySide6.QtGui import QColor, QPainter, QIcon
        from PySide6.QtWidgets import QToolTip
        from .color_palettes import COLOR_PALETTES
        self._color_actions = {}
        groups = {name: self._colors_menu.addMenu(name) for name in ("Bold", "Soft", "Classic")}
        for colors in COLOR_PALETTES:
            menu = groups[colors['group']]
            swatch = QPixmap(60, 18)
            painter = QPainter(swatch)
            for index, name in enumerate(('bg', 'panel', 'fg')):
                painter.fillRect(index * 20, 0, 20, 18, QColor(colors[name]))
            painter.end()
            action = QAction(QIcon(swatch), colors['name'], self, checkable=True)
            action.setChecked(self.config.get('theme', 'dark') == colors['id'])
            action.triggered.connect(lambda _checked=False, mode=colors['id']: self._set_theme(mode))
            action.hovered.connect(lambda palette=colors, item=action, parent=menu:
                                   self._preview_colors(palette, item, parent))
            menu.addAction(action)
            self._color_actions[colors['id']] = action
        for menu in groups.values():
            menu.aboutToHide.connect(QToolTip.hideText)

    def _preview_colors(self, colors, action, menu) -> None:
        from PySide6.QtCore import QPoint
        from PySide6.QtWidgets import QToolTip
        # Preview only this card. Hover never changes the app palette or saved settings.
        preview = (f"<table cellpadding='10' bgcolor='{colors['bg']}'><tr><td>"
                   f"<font color='{colors['fg']}'><b>{colors['name']}</b><br>Station · Genre</font>"
                   f"</td></tr><tr><td bgcolor='{colors['panel']}'>"
                   f"<font color='{colors['fg']}'>Click to apply these colors</font></td></tr></table>")
        QToolTip.showText(menu.mapToGlobal(menu.actionGeometry(action).topRight()) + QPoint(12, 0),
                          preview, menu)

    def _rebuild_theme_menu(self) -> None:
        """(Re)build the View → Theme submenu from the live theme registry (so user themes
        imported at runtime show up too)."""
        self._theme_menu.clear()
        self._theme_actions = {}
        current = self.config.get("theme", "dark")
        for mode, label in theme.THEME_LABELS.items():
            if mode.startswith('bs-'):
                continue  # the grouped Colors menu presents these palettes
            a = QAction(label, self, checkable=True)
            a.setChecked(current == mode)
            a.triggered.connect(lambda _=False, m=mode: self._set_theme(m))
            self._theme_menu.addAction(a)
            self._theme_actions[mode] = a

    def _set_theme(self, mode: str) -> None:
        self.config.set("theme", mode)
        self.config.save_settings()
        self._apply_appearance(mode)
        for m, a in {**self._theme_actions, **self._color_actions}.items():
            a.setChecked(m == mode)
        self.statusBar().showMessage(f"{theme.THEME_LABELS.get(mode, mode)} theme")

    def _rebuild_wallpaper_menu(self) -> None:
        """(Re)build the View → Wallpaper submenu: Off, the built-in wallpapers, and Load image…
        The checkmark reflects the current setting (mirrors Options → Themes → Wallpaper)."""
        from .wallpaper import BUILTIN_WALLPAPERS
        self._wallpaper_menu.clear()
        on = bool(self.config.get("wallpaper_enabled", True))
        cur = self.config.get("wallpaper_image", "") or ""
        known = {spec for spec, _ in BUILTIN_WALLPAPERS}

        off = QAction("Off", self, checkable=True)
        off.setChecked(not on)
        off.triggered.connect(lambda _=False: self._set_wallpaper_choice(None))
        self._wallpaper_menu.addAction(off)
        self._wallpaper_menu.addSeparator()
        for spec, label in BUILTIN_WALLPAPERS:
            a = QAction(label, self, checkable=True)
            a.setChecked(on and cur == spec)
            a.triggered.connect(lambda _=False, s=spec: self._set_wallpaper_choice(s))
            self._wallpaper_menu.addAction(a)
        self._wallpaper_menu.addSeparator()
        load = QAction("Load image…", self, checkable=True)
        load.setChecked(on and cur != "" and cur not in known)   # an absolute custom path is active
        load.triggered.connect(lambda _=False: self._set_wallpaper_choice("__load__"))
        self._wallpaper_menu.addAction(load)

    def _set_wallpaper_choice(self, choice) -> None:
        """View → Wallpaper pick: None = off; '__load__' = file dialog; else a spec ('' = theme
        default, 'synthwave'/'vaporwave-1'/…, or an absolute image path)."""
        from .wallpaper import BUILTIN_WALLPAPERS
        if choice is None:
            self.config.set("wallpaper_enabled", False)
            msg = "Wallpaper off"
        else:
            if choice == "__load__":
                from PySide6.QtWidgets import QFileDialog
                path, _ = QFileDialog.getOpenFileName(self, "Load wallpaper image", "",
                                                      "Images (*.png *.jpg *.jpeg *.webp *.bmp *.gif)")
                if not path:
                    self._rebuild_wallpaper_menu()       # cancelled -> restore the checkmarks
                    return
                choice = path
            self.config.set("wallpaper_enabled", True)
            self.config.set("wallpaper_image", choice)
            msg = f"Wallpaper: {dict(BUILTIN_WALLPAPERS).get(choice, choice)}"
        self.config.save_settings()
        self._apply_appearance(self.config.get("theme", "dark"))
        self._rebuild_wallpaper_menu()
        self.statusBar().showMessage(msg)

    def _on_wallpaper_changed(self) -> None:
        """The Options dialog changed the wallpaper -> re-apply and resync the View menu checkmarks."""
        self._apply_appearance(self.config.get("theme", "dark"))
        self._rebuild_wallpaper_menu()

    def _active_wallpaper_spec(self, mode: str) -> str:
        """Which wallpaper to show: the user's chosen image if any, else the theme's built-in one
        (only Synthwave ships one) — or '' when wallpaper is switched off."""
        if not self.config.get("wallpaper_enabled", True):
            return ""
        custom = (self.config.get("wallpaper_image", "") or "").strip()
        return custom or theme.theme_wallpaper(mode)

    def _paint_favourite_star(self, mode: str) -> None:
        """The Favorite button's star: a plain outline when the station is not a favourite, a filled gold star
        when it is. Only the star lights up, never the whole button."""
        from PySide6.QtCore import QPointF
        from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPolygonF
        dark = theme.is_dark(mode)
        gold = QColor("#edc064" if dark else "#a06c00")
        outline = QColor(*theme._theme(mode)["text"])
        outline.setAlpha(190)
        points = QPolygonF([QPointF(x, y) for x, y in ((8, 1.5), (10.1, 5.8), (14.8, 6.4), (11.4, 9.7), (12.3, 14.4),
                                                       (8, 12.1), (3.7, 14.4), (4.6, 9.7), (1.2, 6.4), (5.9, 5.8))])
        icon = QIcon()
        for state, fill in ((QIcon.Off, None), (QIcon.On, gold)):
            for icon_mode in (QIcon.Normal, QIcon.Disabled):
                pixmap = QPixmap(32, 32)
                pixmap.setDevicePixelRatio(2)
                pixmap.fill(Qt.transparent)
                painter = QPainter(pixmap)
                painter.setRenderHint(QPainter.Antialiasing)
                ink = QColor(fill if fill is not None else outline)
                if icon_mode == QIcon.Disabled:
                    ink.setAlpha(80)
                painter.setPen(QPen(ink, 1.4))
                painter.setBrush(ink if fill is not None else Qt.NoBrush)
                painter.drawPolygon(points)
                painter.end()
                icon.addPixmap(pixmap, icon_mode, state)
        self.act_fav.setIcon(icon)

    def _apply_appearance(self, mode: str) -> None:
        """Apply theme + wallpaper + font together: palette, a translucency-aware stylesheet, the app
        font, and the wallpaper pixmap. Used at startup and on every theme/wallpaper/font change."""
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        spec = self._active_wallpaper_spec(mode)
        fam, px = theme.app_font(self.config)
        f = app.font()
        if not hasattr(app, "_streamtuner_default_font_family"):
            app._streamtuner_default_font_family = f.family()
        f.setFamily(fam or app._streamtuner_default_font_family)
        f.setPixelSize(px)
        app.setFont(f)
        app.setPalette(theme.palette(mode))                              # keep OS dark-mode from bleeding in
        self._paint_favourite_star(mode)
        shown = self._apply_wallpaper(spec)       # first: the panels are only see-through when an image sits behind them
        app.setStyleSheet(theme.stylesheet(mode, translucent=shown, font_family=fam, font_px=px))
        tray = getattr(self, "_tray", None)
        if tray is not None and hasattr(tray.contextMenu(), "refresh"):
            tray.contextMenu().refresh()
        if spec and not shown:
            self.statusBar().showMessage(f"Wallpaper image not found or unreadable: {spec[:120]}", 8000)

    def _apply_wallpaper(self, spec: str) -> bool:
        """Show the wallpaper for ``spec``; True when an image really is behind the window now."""
        wd = getattr(self, "_wallpaper_widget", None)
        if wd is None:
            return bool(spec)
        from .wallpaper import load_wallpaper
        base = theme.user_theme_dir(self.config) if (spec and spec != "synthwave") else None
        pix = load_wallpaper(spec, base) if spec else None
        wd.set_wallpaper(pix, int(self.config.get("wallpaper_dim", 35)))
        return pix is not None

    def _reload_category(self, item) -> None:
        if item and item.text() != "Loading…":
            self._reload(preferred=item.text())

    def _clear_channel_cache(self, cid) -> None:
        self._invalidate_source(cid)
        for key in list(self._cache):
            if key[0] == cid:
                self._cache.pop(key, None)
        self._cat_cache.pop(cid, None)
        run_cache(lambda: self.config.cache_clear_channel(cid), lambda *_: None)
        self._update_cache_label()


    def _reload(self, *_a, preferred=None) -> None:
        cid = self.current_channel
        if not cid:
            return
        if cid == "bookmarks" and self.config.get("reload_favorites_song", True):
            QTimer.singleShot(400, self._ask_favorite_songs)        # after the list has been rebuilt
        if self.host.health[cid].auto_disabled:
            self.host.set_enabled(cid, True)
        selected = preferred or self.current_category
        self._refresh_view_key = (cid, selected)
        self._reset_load()
        self._invalidate_source(cid)
        self._next_channel_gen()
        self._load_gen += 1
        self._refreshing = True
        self._view_search = False
        self._search_query = None
        self._cache.mark_stale(cid)
        self._list_message(f"Refreshing {self.host.channels[cid].title} — saved stations remain available")
        self._fetch_categories(cid, self._channel_gen, selected, fresh=True)


    SONG_ASK_LIMIT = 100
    SONG_ASK_PARALLEL = 3

    def _music_playing(self) -> bool:
        """Is a station playing right now? Background work then goes one step at a time."""
        try:
            return bool(self._playing_row) and bool(self.player.is_playing)
        except Exception:  # noqa: BLE001
            return False

    def _ask_favorite_songs(self) -> None:
        """F5 in Favorites/History: ask the first 100 listed stations' streams which song they announce now
        (each address once, three at a time — two while music plays — at low priority) and show the answers in the Playing column."""
        from ..net.http import run_low
        from ..songnow import current_song
        if self._closing or self.current_channel != "bookmarks":
            return
        urls, seen = [], set()
        for r in range(self.model.rowCount()):
            row = self.model.row_at(r)
            if row and row["url"] not in seen:
                seen.add(row["url"])
                urls.append(row["url"])
            if len(urls) >= self.SONG_ASK_LIMIT:
                break
        self._song_ask_gen += 1
        gen, pending, state = self._song_ask_gen, list(reversed(urls)), {"active": 0, "asked": 0, "answers": 0}
        total = len(urls)
        if not total:
            return
        found = dict(self.model.live_songs)

        def pump() -> None:
            while pending and state["active"] < (2 if self._music_playing() else self.SONG_ASK_PARALLEL):
                url = pending.pop()
                state["active"] += 1
                run_async(lambda u=url: run_low(current_song, u), lambda song, u=url: landed(u, song), priority=20)

        def landed(url, song) -> None:
            state["active"] -= 1
            state["asked"] += 1
            if self._closing or gen != self._song_ask_gen:
                return
            if isinstance(song, str) and song:
                state["answers"] += 1
                found[url] = song
                self.model.set_live_songs(found)
            if pending or state["active"]:
                self.statusBar().showMessage(f"Playing songs: asked {state['asked']} of {total} stations…")
                pump()
            else:
                self.statusBar().showMessage(
                    f"Playing songs: {state['answers']} of {total} favorites announce a song now", 10000)
        self.statusBar().showMessage(f"Playing songs: asking {total} stations…")
        pump()

    def _refresh_channel_cache(self, cid) -> None:
        if self.current_channel == cid:
            self._reload()
        else:
            self._invalidate_source(cid)
            self._cache.mark_stale(cid)
            self._cat_ages[cid] = 0


    def _update_cache_label(self) -> None:
        self._cache_label.setText("")
        self._cache_label.setToolTip(f"{len(self._cache)} cached lists; {self._cache.row_count:,} rows")


    def _bg_refresh(self, cid, cat, done=None, also_cancel=None) -> None:
        """Fetch one list again in the background and save it. `done(ok)` is called once, with whether
        the saved copy was replaced (Reload all counts these). `also_cancel` is an extra event that stops
        the fetch (Reload all's own)."""
        key = (cid, cat)
        if self._closing or cid in self.INTERNAL_CHANNELS or not cat or key in self._bg_inflight \
                or key == self._loading_key:
            if done is not None:
                done(False)
            return
        if done is not None:
            self._bg_done[key] = done
        self._bg_inflight.add(key)
        epoch, generation = self._cache_epoch.get(cid, 0), self._cache_generation
        cancel = self._cache_event(cid)
        if also_cancel is not None:
            from .reloadall import EitherEvent
            cancel = EitherEvent(cancel, also_cancel)
        ch = self.host.channels[cid]
        def refresh():
            # The category list was fetched a moment ago (Reload all, another list of this feed): do not download
            # a whole directory again for every list; only a stale one is fetched afresh.
            recent = time.monotonic() - self._cat_ages.get(cid, 0) < self._CATEGORIES_REUSE_S
            categories = self.host.call(cid, "update_categories" if recent else "refresh_categories",
                                        timeout=45, cancel_event=cancel, background=True)
            if not categories.ok:
                return categories
            if not recent:
                self._cat_ages[cid] = time.monotonic()
            rows, seen, errors = [], set(), []
            offset, complete = 0, True
            while not cancel.is_set():
                limit = getattr(ch, "page_size", None) if offset == 0 else getattr(ch, "page_batch_size", None)
                result = self.host.call(cid, "update_streams_page", cat, offset, limit or self.ALL_LIMIT, None,
                                        timeout=45, cancel_event=cancel, background=True)
                if not result.ok:
                    return result
                complete &= getattr(result, "complete", True)
                errors.extend(getattr(result, "errors", ()) or ())
                for row in result.data or []:
                    if row["url"] not in seen:
                        seen.add(row["url"])
                        rows.append(row)
                more, next_offset = self._page_continuation(ch, cat, offset, result)
                if not more:
                    return Result(Status.OK, data=rows, complete=complete, errors=tuple(errors))
                if len(rows) >= self.ALL_LIMIT:
                    return Result(Status.OK, data=rows[:self.ALL_LIMIT], complete=False,
                                  errors=("Catalog limit reached",))
                offset = next_offset
            return Result(Status.ERROR, message="Refresh cancelled")
        run_async(refresh, lambda result: self._apply_bg_refresh(key, result, epoch, generation),
                  priority=10, cancelled=cancel)


    def _apply_bg_refresh(self, key, res, epoch=None, generation=None) -> None:
        self._bg_inflight.discard(key)
        done = self._bg_done.pop(key, None)
        cid, cat = key
        if (self._closing or epoch is not None and epoch != self._cache_epoch.get(cid, 0)
                or generation is not None and generation != self._cache_generation):
            if done is not None:
                done(False)
            return
        if not (getattr(res, "ok", False) and getattr(res, "complete", True)
                and not getattr(res, "errors", ())):
            if (self.current_channel, self.current_category) == key:
                self._list_message("Showing saved stations — refresh incomplete; use Retry")
                self._retry_button.show()
            if done is not None:
                done(False)
            return
        if done is not None:
            done(True)
        rows = res.data or []
        unchanged = self._cache.get(key) == rows      # the same stations again: leave the list, its selection and its live songs alone
        self._cache[key] = rows
        self._save_catalog(cid, cat, rows)
        self._update_cache_label()
        if (self.current_channel, self.current_category) == key and key != self._loading_key and not self._view_search:
            if not unchanged:
                self._replace_rows(rows, validated=True)
            self._list_message(f"{cat}: {'up to date' if unchanged else 'refreshed'} ({len(rows):,} stations)")


    def _periodic_refresh(self) -> None:
        if not self.isVisible() or self.isMinimized():
            self._refresh_due = True              # hidden in the tray or minimised: nobody sees it, so wait until they return
            return
        self._refresh_due = False
        cid, cat = self.current_channel, self.current_category
        derived = cat == getattr(self.host.channels.get(cid), "listeners_category", "")
        big = (cat == getattr(self.host.channels.get(cid), "all_category", None)
               or self.model.rowCount() > self._REFRESH_MAX_ROWS)
        if cid and cat and not self._view_search and not derived and not big:
            self._bg_refresh(cid, cat)


    def _toggle_mute(self) -> None:
        self._set_muted(not getattr(self, "_muted", False), announce=True)

    def _set_muted(self, on: bool, announce: bool = False) -> None:
        """Mute or un-mute the app's own sound. The volume (slider, saved setting) is left alone, so un-muting
        returns to the same level. Every control for it (Vol button, Ctrl+M, menu, tray, volume key) lands here."""
        on = bool(on)
        if on == getattr(self, "_muted", False):
            return
        self._muted = on
        setter = getattr(self.player, "set_muted", None)
        if setter is not None:
            setter(on)
        button = getattr(self, "btn_vol", None)
        if button is not None:
            button.setText("Muted" if on else "Vol")
            button.setProperty("muted", on)
            button.style().unpolish(button)
            button.style().polish(button)
            button.setToolTip("Click to un-mute  (Ctrl+M)" if on else "Click to mute  (Ctrl+M)")
        action = getattr(self, "act_mute", None)
        if action is not None and action.isChecked() != on:
            action.setChecked(on)
        self._refresh_tray_mute()
        if announce:
            self.statusBar().showMessage("Muted" if on else f"Volume {self.vol.value()}%", 2000)

    def _refresh_tray_mute(self) -> None:
        tray = getattr(self, "_tray", None)
        if tray is None:
            return
        from .tray import tray_icon, MUTED_EMOJI, emoji_icon
        tray.setIcon(emoji_icon(MUTED_EMOJI) if self._muted else tray_icon(self.config))
        sync = getattr(tray.contextMenu(), "sync_mute", None)
        if sync is not None:
            sync(self._muted)
        self._update_tray_np(getattr(self, "_tray_np_text", ""))

    def _nudge_volume(self, delta: int) -> None:
        """Bump the app's OWN (mpv) volume — bound to the Volume keys + Ctrl+Up/Down, so when the
        app is focused they control playback volume instead of the system mixer."""
        self._set_muted(False)                                  # a volume key always brings the sound back
        self.vol.setValue(max(0, min(100, self.vol.value() + delta)))   # moves slider -> set_volume + save
        self.statusBar().showMessage(f"Volume {self.vol.value()}%", 1500)

    def _setup_shortcuts(self) -> None:
        from PySide6.QtGui import QKeySequence, QShortcut

        def sc(seq, fn) -> None:
            QShortcut(QKeySequence(seq), self).activated.connect(fn)
        sc("Space", self._space_pressed)                     # play / pause (search box keeps its space)
        sc("Ctrl+P", self._toggle_play)
        sc(Qt.Key_MediaPlay, self._toggle_play)
        sc(Qt.Key_MediaTogglePlayPause, self._toggle_play)
        sc("Ctrl+.", self._stop)
        sc(Qt.Key_MediaStop, self._stop)
        sc(Qt.Key_VolumeMute, self._toggle_mute)
        sc(Qt.Key_VolumeUp, lambda: self._nudge_volume(5))     # app volume when focused (not system)
        sc(Qt.Key_VolumeDown, lambda: self._nudge_volume(-5))
        sc("Ctrl+Up", lambda: self._nudge_volume(5))           # reliable in-app vol (Volume keys can be OS-grabbed)
        sc("Ctrl+Down", lambda: self._nudge_volume(-5))
        sc("Ctrl+R", self._reload)
        sc("F6", lambda: self._step_pane(1))                 # Services -> Categories -> Stations
        sc("Shift+F6", lambda: self._step_pane(-1))
        sc("Ctrl+F", self._focus_search)
        sc("Ctrl+Shift+F", self._focus_search_all)         # search every source, keeping the typed text
        sc("Ctrl+D", self._toggle_favourite)                 # add/remove the selected station
        esc = QShortcut(QKeySequence(Qt.Key_Escape), self.search)   # Esc clears the focused search box
        esc.activated.connect(self.search.clear)

    def _setup_media_keys(self) -> None:
        """OS-global media keys (Play/Pause, Stop, Next, Prev) so they work even when the window is
        minimized or unfocused. Windows-only today (RegisterHotKey via ctypes); a graceful no-op
        elsewhere, where the focused-window shortcuts above still handle the keys."""
        from .mediakeys import MediaKeys
        self._media_keys = MediaKeys({
            "play_pause": self._toggle_play,
            "stop": self._stop,
            "next": lambda: self._play_relative(1),
            "prev": lambda: self._play_relative(-1),
        })
        try:
            self._media_keys.install(int(self.winId()))   # winId() realizes the native window -> HWND
        except Exception:  # noqa: BLE001 — never let a hotkey quirk block startup
            pass

    def _play_relative(self, delta: int) -> None:
        """Media Next/Prev: step the selection by one visible row and play it (live-radio
        'next/previous station')."""
        n = self.proxy.rowCount()
        if not n:
            return
        cur = self.table.currentIndex()
        r = max(0, min(n - 1, (cur.row() if cur.isValid() else -1) + delta))
        idx = self.proxy.index(r, 0)
        if idx.isValid():
            self.table.setCurrentIndex(idx)
            self.table.scrollTo(idx)
            self._play_selected()

    def _focus_search(self) -> None:
        self.search.setFocus()
        self.search.selectAll()

    def _update_stream_status(self) -> None:
        self._sync_visualizer()
        self._sync_selection_actions()
        errors = self.config.take_write_errors() if hasattr(self.config, "take_write_errors") else []
        if errors:
            self._status_error("Data could not be saved: " + self.config.redact("; ".join(errors)))
        try:
            if self.player.is_playing:
                title = self.player.now_playing()        # poll the live track (reliable)
                if title and title != self._np_full:
                    self._on_nowplaying(title)           # updates player bar + the table cell
                # trust the STREAM, not the directory: show mpv's actual decoded bitrate/codec
                kbps, codec = self.player.audio_format()
                codec = codec.replace("mpeg", "mp3").replace("float", "").strip()
                meta = " / ".join(p for p in (f"{kbps}k" if kbps else "", codec) if p)
                if meta and meta != self._np_meta:
                    self._np_meta = meta
                    self._elide_np()                     # reflect it after the title in the bar too
                buf = self.player.buffer_percent()
                if self._playing_row:
                    if isinstance(buf, (int, float)) and buf < 100:
                        self.np_label.setText(f"Buffering — {self._np_full}")
                    elif codec:
                        self._elide_np()
                    else:
                        self.np_label.setText(f"Connecting — {self._np_full}")
                bits = [b for b in (self._np_meta.strip(), f"buffer {buf}%" if buf is not None else "") if b]
                self._stream_label.setText("▶ " + " · ".join(bits) if bits else "▶")
                if self._stream_retries and time.monotonic() - self._play_started_at > 20:
                    self._stream_retries = 0                  # it has played steadily: the next drop starts afresh
            else:
                self._stream_label.setText("" if self.player.available else "⚠ no audio engine")
                if (not self._pending_play and self.btn_play.isChecked() and self._playing_row
                        and time.monotonic() - self._play_started_at > 1):
                    failure = getattr(self.player, 'playback_error', '')
                    if not self._retry_dropped_stream():
                        self._stop()
                        if isinstance(failure, str) and failure:
                            self._status_error("Stream unavailable: " + self.config.redact(failure)
                                               + " — press Play to try again")
                        else:
                            self.statusBar().showMessage("Playback ended")
        except Exception:  # noqa: BLE001 — the 1 s status poll must never take down the app
            pass

    # ---- Discord Rich Presence (optional) ----
    def _discord_enabled(self) -> bool:
        return bool(self.config.get("discord_rpc", False))

    def _discord_get(self):
        """The DiscordPresence, built lazily with the app's built-in client id; None when off."""
        if not self._discord_enabled():
            return None
        if self._discord is None:
            from ..discord_presence import DISCORD_APP_ID, DiscordPresence
            self._discord = DiscordPresence(DISCORD_APP_ID)
        return self._discord

    _DISCORD_MIN = 30.0   # min seconds between presence writes (well under Discord's ~5/20s limit)

    def _discord_update(self, details: str, state: str, reset: bool = False) -> None:
        self._discord_queue((details, state, reset))

    def _discord_clear(self) -> None:
        self._discord_queue("CLEAR")

    def _discord_queue(self, action) -> None:
        """Throttle presence writes: send immediately when enough time has passed, else coalesce
        the burst and send only the LATEST after the interval — so rapid station-hopping can't spam
        Discord or trip its rate limit."""
        if self._discord_get() is None:                  # disabled / no App ID
            self._discord_pending = None
            return
        if action == "CLEAR":
            self._discord_pending = None
            self._discord_timer.stop()
            self._discord.clear()
            return
        self._discord_pending = action
        elapsed = time.monotonic() - self._discord_last
        if elapsed >= self._DISCORD_MIN:
            self._discord_flush()
        elif not self._discord_timer.isActive():
            self._discord_timer.start(int((self._DISCORD_MIN - elapsed) * 1000))

    def _discord_flush(self) -> None:
        action, self._discord_pending = self._discord_pending, None
        if action is None:
            return
        self._discord_last = time.monotonic()
        d = self._discord_get()
        if d is None:
            return
        try:
            if action == "CLEAR":
                d.clear()
            else:
                d.update(action[0], action[1], reset_elapsed=action[2])
        except Exception:  # noqa: BLE001 — presence must never disrupt playback
            pass

    def _tick_viz(self) -> None:
        """Drive the active visualization from the live audio levels (~30 fps). Never crash."""
        if not self._visualizer_active():
            return
        try:
            levels = self.player.audio_levels() if self.player.is_playing else None
            if self._viz == "vu":
                if levels:
                    self.vu.set_db(*levels)
                else:
                    self.vu.idle()
            elif self._viz == "spectrogram":
                if levels:
                    L, R, Lpk, Rpk = levels
                    rms = (L + R) / 2.0
                    self.spectro.push(rms, max(0.0, (Lpk + Rpk) / 2.0 - rms))
                else:
                    self.spectro.idle()
        except Exception:  # noqa: BLE001 — a meter must never take down playback
            pass

    def _on_search(self, text) -> None:
        self._pending_filter = text
        if self.search_scope.currentIndex() == 0:
            self._search_timer.start(220)
        elif not text and self._view_search:
            QTimer.singleShot(0, self._back_to_category)


    def _apply_filter(self) -> None:
        text = self._pending_filter
        self.proxy.setFilterFixedString(text)
        total = self.model.rowCount()
        if text:
            count = self.proxy.rowCount()
            self._list_message(f"{count:,} of {total:,} stations" if count else "No matches in this list — clear the filter or search this source")


    def _search_enter(self) -> None:
        query = self.search.text().strip()
        if not query:
            return
        scope = self.search_scope.currentIndex()
        if scope == 2:
            self._search_all_sources(query)
        elif scope == 1:
            self._search_channel(self.current_channel, query)
        else:
            self._apply_filter()


    def _search_channel(self, cid, query) -> None:
        channel = self.host.channels.get(cid)
        if not getattr(channel, "has_search", False):
            self._list_message("This service supports filtering its loaded list; choose Loaded list")
            return
        self._reset_load()
        self._load_gen += 1
        self._view_search = True
        self._nav_update()
        self._search_query = query
        self._back_button.show()
        self._search_timer.stop()
        self.proxy.setFilterFixedString("")
        self.model.set_rows([])
        self._list_message(f"Searching {channel.title} for “{query}”…")
        cat = self.current_category or getattr(channel, "all_category", "") or ""
        self._load_page(cid, cat, 0, getattr(channel, "page_size", None) or self.ALL_LIMIT, self._load_gen)


    def _search_all_sources(self, query) -> None:
        candidates = [cid for cid, ch in self.host.channels.items()
                      if getattr(ch, "has_search", False) and self.host.is_enabled(cid)]
        if not candidates:
            self._list_message("No searchable services are enabled")
            return
        self._reset_load()
        self._load_gen += 1
        self._view_search = True
        self._nav_update()
        self._search_query = query
        self._search_timer.stop()
        self.proxy.setFilterFixedString("")
        self.model.set_rows([])
        self._search_acc = {}
        self._search_pending = set(candidates)
        self._search_failures = {}
        self._search_done = set()
        self._back_button.show()
        self._cancel_button.show()
        self._list_message(f"Searching {len(candidates)} services…")
        for cid in candidates:
            self._search_source_page(self._load_gen, cid, query, 0)


    def _on_all_results(self, gen, cid, query, result) -> None:
        self._on_all_page(gen, cid, query, 0, result)


    def _open_website(self, url: str) -> None:
        if not valid_url(url, web=True):
            self._status_error("Only HTTP(S) website links can be opened")
            return
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl(url))

    def _open_local_folder(self, url: str) -> None:
        """Open a plugin's file:// folder (channel homepage of a local_files plugin) in the file
        manager. Only an existing directory is opened; files and other schemes are refused."""
        from pathlib import Path
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        if not valid_url(url, local=True):
            from urllib.parse import urlsplit
            host = urlsplit(url).netloc
            self._status_error(
                f"Folder link has a host name ('{host[:40]}'); build it with Path(folder).as_uri()"
                if host and host != "localhost" else "Not a valid local folder link")
            return
        path = Path(QUrl(url).toLocalFile())
        if not path.is_dir():
            self._status_error("That folder does not exist")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _open_location(self) -> None:
        from .dialogs import open_location
        url = open_location(self, self.config.get("theme", "dark"))
        if not url:
            return
        self._play_gen += 1
        self._start_playback({"title": redact_url(url), "url": url}, None, self._play_gen)

    def _add_local(self) -> None:
        from .dialogs import MAX_LOCAL_BATCH_URLS, new_station
        if self._closing or self._local_add_pending:
            return
        result = new_station(self, self.config.get("theme", "dark"))
        if not result:
            return
        local = self.host.channels.get("local")
        if local is None:
            self._status_error("The Local station list is unavailable")
            return
        if not isinstance(result, dict) or type(result.get("bulk")) is not bool:
            self._status_error("Station details were incomplete; nothing was saved")
            return
        urls = result.get("urls")
        if (not isinstance(urls, list) or not urls
                or any(not isinstance(url, str) or not valid_url(url, token=True) for url in urls)):
            self._status_error("A stream URL was invalid; nothing was saved")
            return
        if result["bulk"] and len(urls) > MAX_LOCAL_BATCH_URLS:
            self._status_error(f"A batch can contain at most {MAX_LOCAL_BATCH_URLS:,} URLs; nothing was saved")
            return

        if result["bulk"]:
            rows = [{"title": redact_url(url), "url": url} for url in urls]
            self._start_local_batch(local, rows)
            return
        if len(urls) != 1:
            self._status_error("Enter one URL for a single station; nothing was saved")
            return
        name = result.get("name", "")
        if not isinstance(name, str):
            self._status_error("Station name was invalid; nothing was saved")
            return
        try:
            row = local.add(name.strip() or redact_url(urls[0]), urls[0])
        except (OSError, ValueError, RuntimeError) as exc:
            self._status_error(f"Could not save to Local: {self.config.redact(exc)}")
            return
        self._show_local_after_add(f"Saved {row['title']} to Local")

    def _start_local_batch(self, local, rows: list[dict]) -> None:
        if self._closing or self._local_add_pending:
            return
        state = {"local": local, "rows": rows, "attempts": 0, "cancel": threading.Event()}
        self._local_add_pending = True
        self._local_add_state = state
        self.act_add_local.setEnabled(False)
        self.statusBar().showMessage(f"Preparing {len(rows):,} stream URLs for Local…")
        self._prepare_local_batch(state)

    def _prepare_local_batch(self, state) -> None:
        if self._closing or state["cancel"].is_set() or self._local_add_state is not state:
            return
        local, rows = state["local"], state["rows"]
        run_io(lambda: local.prepare_many(rows), self._on_local_batch_prepared,
               cancelled=state["cancel"])

    def _on_local_batch_prepared(self, result) -> None:
        state = self._local_add_state
        if self._closing or not self._local_add_pending or state is None:
            return
        if isinstance(result, BaseException):
            self._finish_local_batch(state, error=f"Could not prepare Local stations: {self.config.redact(result)}")
            return
        local = state["local"]
        if not local.plan_is_current(result):
            self._replan_local_batch(state)
            return
        try:
            applied = local.apply_many_plan(result)
        except (OSError, ValueError, RuntimeError) as exc:
            self._finish_local_batch(state, error=f"Could not save to Local: {self.config.redact(exc)}")
            return
        if not applied:
            self._replan_local_batch(state)
            return
        added = result.stations_added
        message = (f"Added {added} station{'s' if added != 1 else ''} to Local"
                   if added else "No new stations added; those stream URLs are already in Local")
        self._finish_local_batch(state, message=message)

    def _replan_local_batch(self, state) -> None:
        if state["attempts"] >= 4:
            self._finish_local_batch(
                state, error="Local stations changed repeatedly during this batch; nothing was saved. Try again.")
            return
        state["attempts"] += 1
        self.statusBar().showMessage("Local stations changed; rechecking the batch…")
        self._prepare_local_batch(state)

    def _finish_local_batch(self, state, *, message: str = "", error: str = "") -> None:
        if self._local_add_state is not state:
            return
        self._local_add_state = None
        self._local_add_pending = False
        if not self._closing:
            self.act_add_local.setEnabled(True)
        if error:
            self._status_error(error)
            return
        if message:
            self._show_local_after_add(message)

    def _show_local_after_add(self, message: str) -> None:
        # Local rows are authoritative in memory; discard any stale view state and
        # return to the list so the user sees the saved or deduplicated result.
        self._clear_channel_cache("local")
        item = next((self.channels.item(index) for index in range(self.channels.count())
                     if self.channels.item(index).data(Qt.UserRole) == "local"), None)
        if item is None:
            self._status_error("Stations were saved, but the Local view is unavailable")
            return
        current = self.channels.currentItem()
        if current is not None and current.data(Qt.UserRole) == "local":
            self._fill_categories("local", ["My Stations"], preferred="My Stations")
        else:
            self.channels.setCurrentItem(item)
        self.statusBar().showMessage(message, 5000)

    def _open_plugins_folder(self) -> None:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices

        from ..plugins.loader import user_plugin_dir
        d = user_plugin_dir(self.config)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(d)))
        self.statusBar().showMessage(f"Drop a .py plugin in: {d}")

    def _on_cache_cleared(self) -> None:
        if self._closing:
            return
        self._cache.clear()
        self._cat_cache.clear()
        self._reload()


    def _open_options(self) -> None:
        from .options import OptionsDialog
        dlg = OptionsDialog(self.host, self.config, self, self.config.get("theme", "dark"))
        dlg.changed.connect(self._on_plugins_changed)
        dlg.visualization_changed.connect(self._set_visualization)
        dlg.volume_changed.connect(self.vol.setValue)
        dlg.album_art_changed.connect(self._toggle_art)
        dlg.settings_changed.connect(self._apply_general_settings)
        dlg.themes_reloaded.connect(self._rebuild_theme_menu)   # a theme was imported
        dlg.theme_changed.connect(self._set_theme)              # a theme was picked/applied
        dlg.cache_clearing.connect(self._before_cache_clear)
        dlg.icons_clearing.connect(self._before_icons_clear)
        dlg.icons_cleared.connect(self._after_icons_clear)
        dlg.cache_cleared.connect(self._on_cache_cleared)       # disk cache cleared -> drop in-memory + reload
        dlg.data_imported.connect(self._on_cache_cleared)       # backup imported -> refresh favourites/local
        dlg.wallpaper_dim_changed.connect(self._wallpaper_widget.set_dim)
        dlg.wallpaper_changed.connect(self._on_wallpaper_changed)
        dlg.font_changed.connect(lambda: self._apply_appearance(self.config.get("theme", "dark")))
        dlg.exec()

    def _apply_general_settings(self) -> None:
        self._toggle_normalize(bool(self.config.get("normalize", False)))
        self._station_favicons = self.config.icon_mode() != "off"
        self._notifications = bool(self.config.get("notifications", True))
        self.model.refresh_icons()           # flip station icons <-> service logo immediately
        self._apply_tray()                   # tray icon / visibility may have changed
        if self._discord_enabled():          # just turned on (or new App ID) -> show now if playing
            if self.player.is_playing and self._playing_row:
                self._discord_update(self._np_full or self._playing_row.get("title", ""),
                                     self._playing_row.get("title", ""), reset=True)
        elif self._discord is not None:      # turned off -> drop the presence + connection
            self._discord.close()
            self._discord = None

    def _on_plugins_changed(self) -> None:
        self._populate_channels()
        self._rebuild_channels_menu()

    def _about(self) -> None:
        from PySide6.QtWidgets import QPushButton

        from .. import asset_path
        from .dialogs import StyledDialog
        dlg = StyledDialog(self, "", self.config.get("theme", "dark"))
        logo = QLabel()
        logo.setAlignment(Qt.AlignCenter)
        _pm = QPixmap(asset_path("logo.png"))
        if not _pm.isNull():
            logo.setPixmap(_pm.scaledToWidth(120, Qt.SmoothTransformation))
        title = QLabel(
            f"<span style='font-size:20px;color:rgb(80,230,150)'><b>{APP_NAME}</b></span>"
            f"<span style='color:{dlg.text_col}'> {__version__}</span>"
        )
        body = QLabel("A modern internet-radio browser.<br>"
                      "Audio by libmpv · UI by Qt · stations from RadioBrowser.")
        body.setStyleSheet(f"color:{dlg.text_col};")
        credit = QLabel("Ported &amp; reimagined by <b>IronWolve</b><br>"
                        "<a href='https://github.com/IronWolve/StreamTuner-ng'>"
                        "github.com/IronWolve/StreamTuner-ng</a>")
        credit.setStyleSheet(f"color:{dlg.text_col};")
        credit.setOpenExternalLinks(True)        # the repo link opens in the browser
        credit.setTextFormat(Qt.RichText)
        close = QPushButton("Close")
        close.clicked.connect(dlg.accept)
        dlg.body.addWidget(logo)
        dlg.body.addWidget(title)
        dlg.body.addWidget(body)
        dlg.body.addWidget(credit)
        dlg.add_buttons(close)
        dlg.exec()

    def _status_error(self, msg: str) -> None:
        self.statusBar().showMessage("⚠ " + self.config.redact(msg))

    def _save_layout(self, *, only_if_changed=False) -> None:
        """Persist window size/position + table column widths/order to config."""
        import base64
        try:
            self.config.set("window_geometry",
                            base64.b64encode(self.saveGeometry().data()).decode("ascii"))
            self.config.set("pane_sizes", self._split.sizes())
            self.config.set("column_state",
                            base64.b64encode(self.table.horizontalHeader().saveState().data()).decode("ascii"))
            snapshot = self.config.settings_snapshot()
            if only_if_changed and snapshot == getattr(self, "_close_settings_snapshot", None):
                return
            self.config.save_settings()
            self._close_settings_snapshot = snapshot
        except Exception:  # noqa: BLE001
            pass

    def _restore_layout(self) -> None:
        import base64

        from PySide6.QtCore import QByteArray
        geo = self.config.get("window_geometry")
        if geo:
            try:
                self.restoreGeometry(QByteArray(base64.b64decode(geo)))
            except Exception:  # noqa: BLE001
                pass
        sizes = self.config.get("pane_sizes", [])
        if isinstance(sizes, list) and len(sizes) == 3 and all(type(x) is int and x >= 0 for x in sizes):
            self._split.setSizes(sizes)
        col = self.config.get("column_state")
        if col:
            try:   # Qt ignores it cleanly if the column count changed (old saved state)
                self.table.horizontalHeader().restoreState(QByteArray(base64.b64decode(col)))
            except Exception:  # noqa: BLE001
                pass

    def _toggle_window(self) -> None:
        """Tray left-click / Show-Hide: restore+raise if hidden or minimised, else hide."""
        if self.isVisible() and not self.isMinimized():
            self.hide()
            self._sync_visualizer()
        else:
            if self.windowState() & Qt.WindowMaximized:
                self.showMaximized()                 # it comes back as it was left, not shrunk to its normal size
            else:
                self.showNormal()
            self.raise_()
            self.activateWindow()
            self._sync_visualizer()

    def _quit(self) -> None:
        """Really exit (tray Quit / Ctrl+Q), bypassing close-to-tray."""
        self._really_quit = True
        self.close()

    def _apply_tray(self) -> None:
        """Re-apply the tray icon + visibility after an Options change."""
        tray = getattr(self, "_tray", None)
        if tray is None:
            return
        from .tray import tray_icon, MUTED_EMOJI, emoji_icon
        tray.setIcon(emoji_icon(MUTED_EMOJI) if getattr(self, "_muted", False) else tray_icon(self.config))
        tray.setVisible(bool(self.config.get("tray_enabled", True)))

    def _update_tray_np(self, text: str) -> None:
        tray = getattr(self, "_tray", None)
        if tray is None:
            return
        self._tray_np_text = text
        label = (text or "").strip() or "Stopped"
        if len(label) > 60:
            label = label[:57] + "…"
        np = getattr(tray, "_np_action", None)
        if np is not None:
            np.setText(label)
        muted = " (muted)" if getattr(self, "_muted", False) else ""
        tray.setToolTip((f"StreamTuner-ng — {label}" if label != "Stopped" else "StreamTuner-ng") + muted)

    def _list_message(self, message):
        self._list_notice.setText(self.config.redact(message))
        self.statusBar().showMessage(self.config.redact(message))

    def _empty_message(self, cid, cat):
        if cid == "bookmarks" and cat == "Favorites":
            return "No favorites yet — choose a station and click Favorite"
        if cid == "bookmarks":
            return "Your recently played stations will appear here"
        if cid == "local":
            return "Add a station with File → New Local Station"
        return "No stations returned — try another category or Retry"

    def _focus_search_all(self) -> None:
        """Ctrl+Shift+F: search every source; the text already typed is kept."""
        self.search_scope.setCurrentIndex(2)
        self.search.setFocus()

    def _scope_changed(self, *_):
        scope = self.search_scope.currentIndex()
        self.search.setPlaceholderText("Filter loaded stations" if scope == 0 else "Search stations…")
        self._search_submit_action.setVisible(scope != 0)
        self.search_submit.setVisible(scope != 0)
        if scope != 0:
            self._search_timer.stop()
            if hasattr(self, "proxy"):
                self.proxy.setFilterFixedString("")
        elif hasattr(self, "proxy"):
            self._on_search(self.search.text())

    def _back_to_category(self, *_):
        if not self._view_search:
            return
        self._view_search = False
        self._search_query = None
        self._back_button.hide()
        self._search_failures.clear()
        self._on_category(self.categories.currentItem(), None)

    def _search_source_page(self, gen, cid, query, offset):
        ch = self.host.channels[cid]
        category = getattr(ch, "all_category", "") or ""
        limit = (getattr(ch, "page_size", None) if not offset else getattr(ch, "page_batch_size", None)) or self.ALL_LIMIT
        cancel = self._load_cancel
        run_async(lambda: self.host.call(cid, "update_streams_page", category, offset, limit, query,
                                         timeout=45, cancel_event=cancel),
                  lambda result: self._on_all_page(gen, cid, query, offset, result), cancelled=cancel)

    def _on_all_page(self, gen, cid, query, offset, result):
        if self._closing or gen != self._load_gen or self._load_cancel.is_set():
            return
        ch = self.host.channels[cid]
        if not isinstance(result, Result) or not result.ok:
            self._search_failures[cid] = self.config.redact(getattr(result, "message", str(result)))
            self._search_pending.discard(cid)
        else:
            new = []
            for row in result.data or []:
                if len(self._search_acc) >= self.ALL_LIMIT:
                    self._search_failures[cid] = "Result limit reached; refine the search"
                    break
                if row["url"] not in self._search_acc:
                    row = dict(row)
                    row.setdefault("_source", cid)
                    self._search_acc[row["url"]] = row
                    new.append(row)
            self.model.append_rows(new, validated=True)
            self._apply_column_visibility()
            errors = getattr(result, "errors", ()) or ()
            if errors or not getattr(result, "complete", True):
                self._search_failures[cid] = self.config.redact("; ".join(errors) or "Partial results")
            more, next_offset = self._page_continuation(ch, getattr(ch, "all_category", "") or "", offset, result)
            if more and len(self._search_acc) < self.ALL_LIMIT:
                self._search_source_page(gen, cid, query, next_offset)
            else:
                self._search_pending.discard(cid)
                if more:
                    self._search_failures[cid] = "Result limit reached; refine the search"
        pending, failed = len(self._search_pending), len(self._search_failures)
        text = f"{self.model.rowCount():,} results"
        if pending:
            text += f"; {pending} services searching…"
        if failed:
            names = ", ".join(self.host.channels[c].title for c in self._search_failures)
            text += f"; {failed} services unavailable or partial: {names}"
        elif not pending and not self.model.rowCount():
            text = "No matching stations — try a different search"
        self._list_message(text)
        self._list_notice.setToolTip("\n".join(f"{self.host.channels[c].title}: {why}"
                                              for c, why in self._search_failures.items()))
        self._cancel_button.setVisible(bool(pending))
        self._retry_button.setVisible(bool(failed) and not pending)

    def _retry_failed_search(self, *_):
        if self._view_search and getattr(self, "_search_pending", set()):
            return
        if self._view_search and self._search_failures:
            failed = tuple(self._search_failures)
            self._search_failures.clear()
            self._search_pending = set(failed)
            self._retry_button.hide()
            self._cancel_button.show()
            self._list_message(f"Retrying {len(failed)} services; keeping previous results…")
            for cid in failed:
                if self.host.health[cid].auto_disabled:
                    self.host.set_enabled(cid, True)
                self._search_source_page(self._load_gen, cid, self._search_query, 0)
        elif self._view_search:
            self._search_channel(self.current_channel, self._search_query)
        else:
            self._reload()

    def _next_channel_gen(self) -> None:
        self._cat_cancel.set()
        self._cat_cancel = threading.Event()
        self._channel_gen += 1

    def _reset_load(self):
        self._load_cancel.set()
        self._load_cancel = threading.Event()
        self._loading_key = None
        self._page_retries.clear()
        self._busy_retries.clear()
        self._load_started = False
        self._load_complete = True
        self._load_errors = []
        self._load_notes = []
        self._retain_during_load = False
        self._fresh_rows = []
        self._fresh_seen = set()
        self._pending_restore = None
        self._search_pending = set()
        self._search_failures = {}
        self._search_acc = {}
        if hasattr(self, "_cancel_button"):
            self._cancel_button.hide()
            self._retry_button.hide()

    def _reload_all(self, *_a) -> None:
        """View -> Reload all (Shift+F5): the open list, then every saved list of every enabled feed."""
        from .reloadall import ReloadAll
        if self._reload_all_job is None:
            self._reload_all_job = ReloadAll(self)
        self._reload_all_job.start()

    def _cancel_load(self, *_):
        if self._reload_all_job is not None and self._reload_all_job.running:
            self._reload_all_job.cancel()
        self._load_cancel.set()
        self._load_gen += 1
        self._next_channel_gen()
        self._loading_key = None
        self._refreshing = False
        self._cancel_button.hide()
        self._list_message("Loading cancelled — displayed stations remain usable")

    @staticmethod
    def _page_continuation(channel, category, offset, result):
        explicit = getattr(result, "has_more", None)
        if explicit is not None:
            next_offset = getattr(result, "next_offset", None)
            if next_offset is None:
                next_offset = offset + (getattr(channel, "page_batch_size", None)
                                        or getattr(channel, "page_size", None) or 1)
            return bool(explicit and next_offset > offset), next_offset
        rows = result.data or []
        if getattr(channel, "all_chunked", False) and category == getattr(channel, "all_category", None):
            return bool(rows), offset + 1
        size = getattr(channel, "page_size", None) if offset == 0 else (getattr(channel, "page_batch_size", None) or getattr(channel, "page_size", None))
        return bool(rows and size and offset + size < MAX_ROWS), offset + (size or 1)

    def _cache_event(self, cid):
        return self._cache_events.setdefault(cid, threading.Event())

    def _invalidate_source(self, cid):
        self._cache_epoch[cid] = self._cache_epoch.get(cid, 0) + 1
        self._cache_event(cid).set()
        self._cache_events[cid] = threading.Event()
        self._bg_inflight = {key for key in self._bg_inflight if key[0] != cid}

    def _save_catalog(self, cid, cat, rows):
        cancel = self._cache_event(cid)
        run_cache(lambda snapshot=list(rows): self.config.cache_save(cid, cat, snapshot, trusted=True),
                  lambda *_: None, key=(cid, cat), cancelled=cancel)

    def _before_cache_clear(self):
        if self._closing:
            return
        self._cache_generation += 1
        self._reset_load()
        self._load_gen += 1
        self._next_channel_gen()
        for cid in self.host.channels:
            self._invalidate_source(cid)
        self._cache.clear()
        self._cat_cache.clear()

    def _trim_icons(self, cache):
        while len(cache) > 512:
            cache.popitem(last=False)
        while len(self._icon_retry_at) > 1024:
            self._icon_retry_at.popitem(last=False)

    def _icon_failed(self, kind, url, result):
        delay = 2 if isinstance(result, BaseException) else 60
        self._icon_retry_at[(kind, url)] = time.monotonic() + delay
        self._trim_icons(self._station_icons)
        self._trim_icons(self._derived_icons)
        QTimer.singleShot(delay * 1000, self._retry_visible_icons)

    def _retry_visible_icons(self):
        if not self._closing:
            self.table.viewport().update()

    def _cancel_pending_icons(self):
        self._icon_cancel.set()
        self._icon_cancel = threading.Event()
        self._icon_epoch += 1
        for cache in (self._station_icons, self._derived_icons):
            for key in [key for key, value in cache.items() if value is None]:
                cache.pop(key, None)

    def _before_icons_clear(self):
        if self._closing:
            return
        self._icons_clearing = True
        self._icon_cancel.set()
        self._icon_cancel = threading.Event()
        self._icon_epoch += 1
        if hasattr(self.config, "invalidate_icons"):
            self.config.invalidate_icons()
        self._station_icons.clear()
        self._derived_icons.clear()
        self._icon_retry_at.clear()
        self._favicons.clear()
        self._svc_icons.clear()

    def _after_icons_clear(self):
        if self._closing:
            return
        self._icons_clearing = False
        self._icon_epoch += 1
        self._station_icons.clear()
        self._derived_icons.clear()
        self._load_channel_favicons()
        self._update_art()
        self.table.viewport().update()

    def _set_column_visible(self, field, enabled):
        if field.startswith("x:"):
            key, cid = field[2:], self.current_channel
            if key in self._extra_starts_hidden(cid):                # secondary: remember what was ticked on
                keys = self._shown_extra(cid)
                keys.add(key) if enabled else keys.discard(key)
                self._store_for_feed("shown_extra_columns", cid, sorted(keys))
            else:                                                    # normal: remember what was hidden
                keys = self._hidden_extra(cid)
                keys.discard(key) if enabled else keys.add(key)
                self._store_for_feed("hidden_extra_columns", cid, sorted(keys))
            self.config.save_settings()
            self._apply_column_visibility()
            return
        cid = self.current_channel
        own = self._overrides(cid)
        if own is None:                           # first change for this feed: start from what it shows now
            own = {name: self._column_wanted(name) for _label, name in COLUMNS if name != "title"}
        own[field] = bool(enabled)
        self._store_for_feed("column_overrides", cid, own)
        self.config.save_settings()
        self._apply_column_visibility()

    def _sync_selection_actions(self):
        row = self._selected_row()
        bm = self.host.channels.get("bookmarks")
        self.act_fav.setEnabled(bool(row and bm))
        self.act_fav.setChecked(bool(row and bm and bm.is_favourite(row["url"])))
        self.act_play.setEnabled(bool(row))
        self.act_stop.setEnabled(bool(self._pending_play or self.player.is_playing))

    def _view_position(self):
        row = self._selected_row()
        return (row.get("url") if row else None, self.table.verticalScrollBar().value())

    def _restore_view_position(self, position):
        if not position:
            return
        url, scroll = position
        index = self.model._positions.get(url)
        if index is not None:
            self.table.setCurrentIndex(self.proxy.mapFromSource(self.model.index(index, 0)))
        self.table.verticalScrollBar().setValue(scroll)

    def _replace_rows(self, rows, *, validated=False):
        position = self._view_position()
        self.model.set_rows(rows, validated=validated)
        self._apply_column_visibility()
        self._restore_view_position(position)

    def _visualizer_active(self):
        return (self._viz != "off" and self.isVisible() and not self.isMinimized()
                and bool(self.player.is_playing) and not self._closing)

    def _sync_visualizer(self):
        active = self._visualizer_active()
        if active and not self._vu_timer.isActive():
            self._vu_timer.start(33)
        elif not active and self._vu_timer.isActive():
            self._vu_timer.stop()
            self.vu.reset()
            self.spectro.reset()
        if hasattr(self.player, "enable_meter") and getattr(self, "_meter_active", None) != active:
            self.player.enable_meter(active)
            self._meter_active = active

    def showEvent(self, event):
        super().showEvent(event)
        if hasattr(self, "_vu_timer"):
            self._sync_visualizer()
        if getattr(self, "_refresh_due", False):
            QTimer.singleShot(1500, self._periodic_refresh)     # the refresh that came due while hidden

    def hideEvent(self, event):
        super().hideEvent(event)
        if hasattr(self, "_vu_timer"):
            self._sync_visualizer()

    def changeEvent(self, event):
        super().changeEvent(event)
        if hasattr(self, "_vu_timer"):
            self._sync_visualizer()
            if getattr(self, "_refresh_due", False) and not self.isMinimized() and self.isVisible():
                QTimer.singleShot(1500, self._periodic_refresh)

    def closeEvent(self, e):
        if self._closing:
            super().closeEvent(e)
            return
        tray = getattr(self, "_tray", None)
        if (not getattr(self, "_really_quit", False)
                and self.config.get("tray_close", False)
                and tray is not None and tray.isVisible()):
            e.ignore()                   # close-to-tray: hide + keep playing; Quit from the tray menu
            self.hide()
            return
        if not self._close_waiting:
            self._song_history.flush_if_dirty()           # a song that failed to save is tried again; the rest is already queued
            self._save_layout()
            if hasattr(self.config, "retry_failed_writes"):
                self.config.retry_failed_writes()
            self._close_waiting = True
            self._close_deadline = time.monotonic() + 5
        else:
            # The window stays interactive while storage drains. Capture edits
            # such as volume/layout that normally save only when closing, while
            # leaving an unchanged pending snapshot alone on every timer tick.
            self._save_layout(only_if_changed=True)
        if any(not event.is_set() for event in self._secret_saves):
            e.ignore()
            if time.monotonic() < self._close_deadline:
                self.statusBar().showMessage("Saving credentials before closing…")
                self._close_timer.start(50)
            else:
                self._close_waiting = False
                self._close_timer.stop()
                self._status_error("Credentials are still being saved. Retry closing after storage is available.")
            return
        if hasattr(self.config, "flush_writes"):
            drained = self.config.flush_writes(timeout=0)
            if not drained and getattr(self.config, "has_unsaved_writes", True):
                e.ignore()
                if (getattr(self.config, "has_pending_writes", True)
                        and time.monotonic() < self._close_deadline):
                    self.statusBar().showMessage("Saving changes before closing…")
                    self._close_timer.start(50)
                else:
                    self._close_waiting = False
                    self._close_timer.stop()
                    self._status_error("Changes are not saved yet. Keep this window open and retry closing after storage is available.")
                return
        self._close_waiting = False
        self._close_timer.stop()
        self._closing = True
        local_add = self._local_add_state
        if local_add is not None:
            local_add["cancel"].set()
        if hasattr(self, "_import_cancel"):
            self._import_cancel.set()
        for cancel in tuple(getattr(self, "_export_cancels", ())):
            cancel.set()
        self._load_cancel.set()
        self._play_cancel.set()
        self._icon_cancel.set()
        if self._reload_all_job is not None:
            self._reload_all_job.shutdown()
        for event in self._cache_events.values():
            event.set()
        self._play_gen += 1
        self._load_gen += 1
        mk = getattr(self, "_media_keys", None)
        if mk is not None:
            mk.uninstall()               # release the global media-key grab
        for t in (self._vu_timer, self._stats_timer, self._refresh_timer,
                  self._discord_timer, self._search_timer, self._icon_refresh):
            t.stop()                     # no stray ticks hitting a torn-down player during teardown
        # stop audio IMMEDIATELY on close so nothing keeps playing after the window's gone
        try:
            self.player.stop()
            self.player.shutdown()
        except Exception:  # noqa: BLE001
            pass
        if self._discord is not None:
            self._discord.close()
        if tray is not None:
            tray.hide()
        from PySide6.QtWidgets import QApplication
        QApplication.instance().quit()   # ensure the process actually exits
        super().closeEvent(e)
